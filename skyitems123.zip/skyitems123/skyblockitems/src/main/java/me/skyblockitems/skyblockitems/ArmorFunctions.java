package me.skyblockitems.skyblockitems;

import de.tr7zw.nbtapi.NBTItem;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.UUID;

import static me.skyblockitems.skyblockitems.ItemManager.*;
import static me.skyblockitems.skyblockitems.ItemManager.adminbtIntel;
import static me.skyblockitems.skyblockitems.SkyblockItems.getInstance;
import static me.skyblockitems.skyblockitems.stats.*;

public class ArmorFunctions implements Listener {
    private final SkyblockItems plugin = SkyblockItems.getInstance();


    public static NBTItem necronChestplateNBT = new NBTItem(NecronsChestplate);
    public static NBTItem necronLeggingNBT = new NBTItem(NecronsLeggings);
    public static NBTItem necronBootNBT = new NBTItem(NecronsBoots);
    public static NBTItem adminBootNBT = new NBTItem(AdminBoots);

    @EventHandler
    public void Armors(PlayerJoinEvent e){
        necronChestplateNBT.setDouble("baseHealth", 620.0);
        necronChestplateNBT.setDouble("baseDefense", 420.0);
        necronChestplateNBT.setDouble("baseIntel", 120.0);
        necronLeggingNBT.setDouble("baseHealth", 540.0);
        necronLeggingNBT.setDouble("baseDefense", 370.0);
        necronLeggingNBT.setDouble("baseIntel", 160.0);
        necronBootNBT.setDouble("baseHealth", 654.0);
        necronBootNBT.setDouble("baseDefense", 130.0);
        necronBootNBT.setDouble("baseIntel",160.0);
        adminBootNBT.setDouble("baseHealth", 10000.0);
        adminBootNBT.setDouble("baseDefense", 10000.0);
        adminBootNBT.setDouble("baseIntel", 10000.0);
    }
}


