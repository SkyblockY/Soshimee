package me.skyblockitems.skyblockitems;

import org.bukkit.Bukkit;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.stream.Collectors;

public class CustomEnchants {

    public static final Enchantment TELEKINESIS = new EnchantmentWrapper("telepathy", "Telepathy", 1);
//    public static final Enchantment GROWTH = new EnchantmentWrapper("growth", "Growth", 1);

    public static void register() {
        boolean registered = Arrays.stream(Enchantment.values()).collect(Collectors.toList()).contains(CustomEnchants.TELEKINESIS);
        if(!registered)
            registerEnchantment(TELEKINESIS);
//            registerEnchantment(GROWTH);
    }

    public static void registerEnchantment(Enchantment enchantment){
        boolean registered = true;
        try{
            Field f = Enchantment.class.getDeclaredField("acceptingNew");
            f.setAccessible(true);
            f.set(null, true);
            Enchantment.registerEnchantment(enchantment);
        } catch(Exception e){
            registered = false;
            e.printStackTrace();
        }if (registered){
            System.out.println("ENCHANT REGISTERED");
        }
    }

}
