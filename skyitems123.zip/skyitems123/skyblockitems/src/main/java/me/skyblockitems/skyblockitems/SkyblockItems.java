package me.skyblockitems.skyblockitems;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;

import java.lang.reflect.Field;
import java.util.Collection;

public final class SkyblockItems extends JavaPlugin {
    private static SkyblockItems instance;

    public static SkyblockItems getInstance() {
        return SkyblockItems.instance;
    }
    private void InitializeItems(){
        System.out.println("hello");
    }

//    private void ranks(){
//        String rankOwner = ChatColor.RED + "[OWNER]";
//        String rankAdmin = ChatColor.RED + "[ADMIN]";
//        String rankNon = ChatColor.GRAY + "[NON]";
//        Bukkit.getOfflinePlayer("Sweattypalms").getPlayer().setDisplayName(rankOwner + "Sweattypalms");
//        Bukkit.getOfflinePlayer("Sweattypalms").getPlayer().setPlayerListName(rankOwner + "Sweattypalms");
//        Bukkit.getOfflinePlayer("56__").getPlayer().setDisplayName(rankAdmin + "56__");
//        Bukkit.getOfflinePlayer("56__").getPlayer().setPlayerListName(rankAdmin + "56__");
//
//
//
//    }


    @Override
    public void onEnable() {
        System.out.println("Hippity \n Hoppity \n thanks for your internet protocol ( real ) \n (totally lmao)");

        SkyblockItems.instance = this;
        ItemManager.init();
        InitializeItems();

        Commands commands = new Commands();
        //GuiClass gclass = new GuiClass();
        getCommand("boss")          .setExecutor(commands);
        getCommand("necron")        .setExecutor(commands);
        getCommand("storm")         .setExecutor(commands);
        getCommand("itemsgui")      .setExecutor(commands);
        getCommand("craft")         .setExecutor(commands);
        getCommand("hub")           .setExecutor(commands);
        getCommand("enchant")       .setExecutor(commands);
        getCommand("enderchest")    .setExecutor(commands);
        getCommand("owner")         .setExecutor(commands);
        getCommand("admin")         .setExecutor(commands);
        getCommand("skyblockmenu")  .setExecutor(commands);
        getCommand("showStats")     .setExecutor(commands);
        getCommand("telekinesis")   .setExecutor(commands);
        getCommand("summonZombie")  .setExecutor(commands);
        getCommand("summonNecron")  .setExecutor(commands);
        getCommand("summonFel")     .setExecutor(commands);
        getCommand("summonDragon")     .setExecutor(commands);
        getCommand("loop")          .setExecutor(commands);
        getCommand("adminboots")    .setExecutor(commands);
        getCommand("plugins")       .setExecutor(commands);
        getCommand("ferocity")      .setExecutor(commands);




// register the classes
        getServer().getPluginManager().registerEvents(new ItemManager(), this);
        getServer().getPluginManager().registerEvents(new GuiClass(), this);
        getServer().getPluginManager().registerEvents(new skyblockMenu(), this);
        getServer().getPluginManager().registerEvents(new stats(), this);
        getServer().getPluginManager().registerEvents(new customEnchantsLogic(), this);
        getServer().getPluginManager().registerEvents(new ItemFunctions(), this);
        getServer().getPluginManager().registerEvents(new ArmorFunctions(), this);
        getServer().getPluginManager().registerEvents(new customMobs(this), this);
        getServer().getPluginManager().registerEvents(new customMobs(this), this);

        CustomEnchants.register();



    }


    @Override
    public void onDisable() {
        // Plugin shutdown logic
        System.out.println("Skyblock Items Plugin has stopped Working.");
    }



}
