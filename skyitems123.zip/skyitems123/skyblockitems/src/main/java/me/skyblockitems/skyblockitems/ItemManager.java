package me.skyblockitems.skyblockitems;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.event.block.Action;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.util.EulerAngle;
import org.bukkit.util.Vector;
import org.bukkit.entity.Player;

import java.util.HashMap;


import java.util.*;

import static me.skyblockitems.skyblockitems.stats.*;
import static org.bukkit.inventory.ItemFlag.HIDE_UNBREAKABLE;


public class ItemManager implements Listener {
    public static ItemStack hyperionItem;
    public static ItemStack terminator;
    public static ItemStack sceptre;
    public static ItemStack aots;
    public static ItemStack canon;
    public static ItemStack protbar;
    public static ItemStack Bonemerang;
    public static ItemStack NecronsChestplate;
    public static ItemStack NecronsLeggings;
    public static ItemStack NecronsBoots;
    public static ItemStack AdminBoots;
    public static ItemStack Gyrowand;
    //    public static ItemStack spacehelm;
    public static ItemStack aotv;
    public static ItemStack sbmenu;
    private final SkyblockItems plugin = SkyblockItems.getInstance();
    public int length = 10;
    public int sceptredmg = 40;
    public int i;
    public int m;
    public static int cpCheck = 0;
    public static int lgCheck = 0;
    public static int btCheck = 0;
    public int passable;
    public int seconds;
    public static int customdata = 0;
    public static int necronCpHealth;
    public static int necronCpIntel;
    public static int necronLgHealth;
    public static int necronLgIntel;
    public static int necronBtHealth;
    public static int necronBtIntel;
    public static int adminbtHealth;
    public static int adminbtIntel;

    public static HashMap<UUID, Double> cooldowns;
    public static HashMap<UUID, Long> withershieldCd;



    public static boolean witherShieldcd(Player p) {
        return !cooldowns.containsKey(p.getUniqueId()) || cooldowns.get(p.getUniqueId()) <= System.currentTimeMillis();
    }


    public static void init() {

        createHype();
        createTerm();
        createAots();
        createSceptre();
        createProtBar();
        createCanon();
//        createSpaceHelm();
        createAotv();
        createBonemerang();
        createSbMenu();
        createNecronsChestplate();
        createNecronsLeggings();
        createNecronsBoots();
        createAdminBoots();
        createGyrowand();
    }


    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent e) {
        // Is target a player, if not stop
        Entity damagee = e.getEntity();
        if(damagee instanceof Player)
            return;
        // Is damager an arrow, if not stop
        if (!(e.getDamager() instanceof Arrow))
            return;
        // Is shooter a player, if not stop
        ProjectileSource src = ((Arrow) e.getDamager()).getShooter();
        if (!(src instanceof Player))
            return;

        i += 1;


    }

    @EventHandler
    public void damageEndermanWithSalvation(EntityDamageByEntityEvent e) {
        if (!(e instanceof Damageable))
            return;
        Player pla = (Player) e.getDamager();
        if (pla.getInventory().getItemInMainHand().getItemMeta().getDisplayName().contains("Terminator")) {
            i += 1;
            pla.sendMessage(String.valueOf(i));

        }
    }

    public static void createGyrowand() {
        ItemStack item = new ItemStack(Material.BLAZE_ROD, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setUnbreakable(true);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.addItemFlags(ItemFlag.HIDE_DESTROYS);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        meta.setDisplayName("§6Gyrokinetic Wand");
        List<String> lore = new ArrayList<>();
        lore.add("§d§lUltimate Wise V");
        lore.add("§7Reduces the ability mana cost of\nthis item by §a50%.");
        lore.add("");
        lore.add("§6Ability: Gravity Storm §eLEFT CLICK");
        lore.add("§7Create a large §5rift §7at aimed");
        lore.add("§7location, pulling all mobs");
        lore.add("§7together.");
        lore.add("§8Regen mana 10x slower for 3s");
        lore.add("§8after cast.");
        lore.add("§8Mana Cost: §3600");
        lore.add("§8Cooldown: §a30s");
        lore.add("");
        lore.add("§6Ability: Cells Alignment §eRIGHT CLICK");
        lore.add("§7Apply §aAligned §7to 4 nearby");
        lore.add("§7players and yourself for §a6s.");
        lore.add("");
        lore.add("6§k§la§6§l LEGENDARY WAND §6§k§la");
        lore.add("§6(Recombobulated)");
        meta.setLore(lore);
        item.setItemMeta(meta);
        Gyrowand = item;

    }

    private static void createNecronsChestplate() {
        ItemStack item = new ItemStack(Material.LEATHER_CHESTPLATE, 1);
        LeatherArmorMeta meta = (LeatherArmorMeta) item.getItemMeta();
        meta.setColor(Color.fromRGB(231, 65, 60));
        meta.setUnbreakable(true);
        meta.setDisplayName("§dAncient Necron's Chestplate §c✪✪✪✪✪");
        List<String> lore = new ArrayList<>();
        lore.add("§7Gear Score:§d1045");
        lore.add("§7Strength:§c +99");
        lore.add("§7Crit Chance:§c +15");
        lore.add("§7Crit Damage:§c +80");
        necronCpHealth = 417;
        lore.add("§7Health:§a +417");
        lore.add("§7Defense:§a +195");
        necronCpIntel = 35;
        lore.add("§7Inteligence:§a +35");
        lore.add("§7True Defense:§a +35");
        lore.add("§6[§d❁§6] §6[§d⚔§6]");
        lore.add("");
        lore.add("§d§lLegion V");
        lore.add("§6Growth VII");
        lore.add("§6Protection VII");
        lore.add("§6Rejuvenate V");
        lore.add("§6True Protection I");
        lore.add("");
        lore.add("§6Full Set Bonus: Witherborn");
        lore.add("§7Spawns a wither minion every");
        lore.add("§e30 §7seconds up to a maximum");
        lore.add("§a1 §7wither. Your withers will");
        lore.add("§7travel to and explode on nearby");
        lore.add("§7 enemies.");
        lore.add("");
        lore.add("§7Reduces the damage you take from");
        lore.add("§7withers by §c10%.");
        lore.add("");
        lore.add("§9Ancient Bonus");
        lore.add("§7Grants §a+1 §9☠ Crit Damage");
        lore.add("§7per §cCatacombs §7level.");
        lore.add("§d§k§la§d§l MYTHIC DUNGEON CHESTPLATE §d§k§la");
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.addItemFlags(ItemFlag.HIDE_DESTROYS);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        meta.setLore(lore);
        item.setItemMeta(meta);
        NecronsChestplate = item;
    }

    private static void createNecronsBoots() {
        ItemStack item = new ItemStack(Material.LEATHER_BOOTS, 1);
        LeatherArmorMeta meta = (LeatherArmorMeta) item.getItemMeta();
        meta.setColor(Color.fromRGB(231, 65, 60));
        meta.setUnbreakable(true);
        meta.setDisplayName("§dAncient Necron's Boots §c✪✪✪✪✪");
        List<String> lore = new ArrayList<>();
        lore.add("§7Gear Score:§d839");
        lore.add("§7Strength:§c +99");
        lore.add("§7Crit Chance:§c +15");
        lore.add("§7Crit Damage:§c +80");
        necronBtHealth = 302;
        lore.add("§7Health:§a +302");
        lore.add("§7Defense:§a +140");
        necronBtIntel = 35;
        lore.add("§7Inteligence:§a +35");
        lore.add("§7True Defense:§a +35");
        lore.add("§6[§d❁§6] §6[§d⚔§6]");
        lore.add("");
        lore.add("§d§lLegion V");
        lore.add("§6Growth VII");
        lore.add("§6Protection VII");
        lore.add("§6Rejuvenate V");
        lore.add("§6Feather Falling X");
        lore.add("§6Sugar Rush III");
        lore.add("");
        lore.add("§d◆ §cR§6a§ei§an§bb§9o§dw §9Rune III");
        lore.add("");
        lore.add("§6Full Set Bonus: Witherborn");
        lore.add("§7Spawns a wither minion every");
        lore.add("§e30 §7seconds up to a maximum");
        lore.add("§a1 §7wither. Your withers will");
        lore.add("§7travel to and explode on nearby");
        lore.add("§7enemies.");
        lore.add("");
        lore.add("§7Reduces the damage you take from");
        lore.add("§7withers by §c10%.");
        lore.add("");
        lore.add("§9Ancient Bonus");
        lore.add("§7Grants §a+1 §9☠ Crit Damage");
        lore.add("§7per §cCatacombs §7level.");
        lore.add("§d§k§la§d§l MYTHIC DUNGEON BOOTS §d§k§la");
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.addItemFlags(ItemFlag.HIDE_DESTROYS);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        meta.setLore(lore);
        item.setItemMeta(meta);
        NecronsBoots = item;
//        if(NecronsBoots.getItemMeta().getLore() != null) {
//            String itemLore = NecronsBoots.getItemMeta().getLore().get(4);
//            String[] args = itemLore.split("§a+");
//            necronCpHealth = Integer.parseInt(args[1]);
//        }
//        if(NecronsBoots.getItemMeta().getLore() != null) {
//            String itemLore1 = NecronsBoots.getItemMeta().getLore().get(6);
//            String[] args1 = itemLore1.split("§a+");
//            necronCpIntel = Integer.parseInt(args1[1]);
//        }
    }

    private static void createAdminBoots() {
        ItemStack item = new ItemStack(Material.LEATHER_BOOTS, 1);
        LeatherArmorMeta meta = (LeatherArmorMeta) item.getItemMeta();
        meta.setColor(Color.fromRGB(249, 0, 0));
        meta.setUnbreakable(true);
        meta.setDisplayName("§cAdmins Boots");
        List<String> lore = new ArrayList<>();
        lore.add("§7Gear Score: §d634");
        lore.add("§7Strength: §c+40");
        lore.add("§7Crit Damage: §c+30%");
        lore.add("");
        adminbtHealth = 260000;
        lore.add("§7Health: §a+260000");
        lore.add("§7Defense: §a+140");
        adminbtIntel = 1000000000;
        lore.add("§7Intelligence: §a+100000");


        lore.add("§c§lEXOTIC ADMIN ARMOR");
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.addItemFlags(ItemFlag.HIDE_DESTROYS);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        meta.setLore(lore);
        item.setItemMeta(meta);
        AdminBoots = item;
//        if(AdminBoots.getItemMeta().getLore().get(4) != null) {
//            String itemLore = AdminBoots.getItemMeta().getLore().get(4);
//            String[] args = itemLore.split("§a+");
//            adminbtHealth = Integer.parseInt(args[1]);
//        }
//        if(AdminBoots.getItemMeta().getLore().get(6) != null) {
//            String itemLore1 = AdminBoots.getItemMeta().getLore().get(6);
//            String[] args1 = itemLore1.split("§a+");
//            adminbtIntel = Integer.parseInt(args1[1]);
//        }
    }

    private static void createNecronsLeggings() {
        ItemStack item = new ItemStack(Material.LEATHER_LEGGINGS, 1);
        LeatherArmorMeta meta = (LeatherArmorMeta) item.getItemMeta();
        meta.setColor(Color.fromRGB(231, 65, 60));
        meta.setUnbreakable(true);
        meta.addItemFlags(HIDE_UNBREAKABLE);
        meta.setDisplayName("§dAncient Necron's Leggings §c✪✪✪✪✪ ");
        List<String> lore = new ArrayList<>();
        lore.add("§7Gear Score:§d 983");
        lore.add("§7Strength:§c +99");
        lore.add("§7Crit Chance:§c +15");
        lore.add("§7Crit Damage:§c +80");
        necronLgHealth = 387;
        lore.add("§7Health:§a +387");
        lore.add("§7Defense:§a +180");
        necronLgIntel = 35;
        lore.add("§7Inteligence:§a +35");
        lore.add("§6[§d❁§6] §6[§d⚔§6]");
        lore.add("");
        lore.add("§d§lLegion V");
        lore.add("§6Growth VII");
        lore.add("§6Protection VII");
        lore.add("§6Rejuvenate V");
        lore.add("");
        lore.add("§8Reduces the damage you take from");
        lore.add("§8withers by §c10%.");
        lore.add("§6Full Set Bonus: Witherborn");
        lore.add("§8Spawns a wither minion every");
        lore.add("§e30 §8seconds up to a maximum");
        lore.add("§a1 §8wither. Your withers will");
        lore.add("§8travel to and explode on nearby");
        lore.add("§8enemies.");
        lore.add("");
        lore.add("§9Ancient Bonus");
        lore.add("§8Grants §a+1 §9☠ Crit Damage");
        lore.add("§8per §cCatacombs §8level.");
        lore.add("§d§k§la§d§l MYTHIC DUNGEON LEGGINGS §d§k§la");
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.addItemFlags(ItemFlag.HIDE_DESTROYS);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        meta.setLore(lore);
        item.setItemMeta(meta);
        NecronsLeggings = item;
//        String itemLore =  NecronsLeggings.getItemMeta().getLore().get(4);
//        String[] args = itemLore.split("§a+");
//        necronLgHealth = Integer.parseInt(args[1]);
//        String itemLore1 =  NecronsLeggings.getItemMeta().getLore().get(6);
//        String[] args1 = itemLore1.split("§a+");
//        necronLgIntel =  Integer.parseInt(args1[1]);

    }

    private static void createSbMenu() {
        ItemStack item = new ItemStack(Material.NETHER_STAR, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.GOLD + "Skyblock Menu");
        item.setItemMeta(meta);
        sbmenu = item;

    }

    private static void createAotv() {
        ItemStack item2 = new ItemStack(Material.DIAMOND_SHOVEL, 1);
        ItemMeta meta = item2.getItemMeta();
        meta.setDisplayName("§6Aspect of the Void");
        List<String> lore = new ArrayList<>();
        lore.add("");
        lore.add("§6Ability: Instant Transmission §e§lRIGHT CLICK");
        lore.add("§7Teleport §a8 blocks§7 ahead of");
        lore.add("§7you and gain §a+50§f Speed");
        lore.add("§7for §a3 seconds§7.");
        lore.add("");
        lore.add("§6§lLEGENDARY");
        meta.setLore(lore);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.addItemFlags(ItemFlag.HIDE_DESTROYS);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        meta.setUnbreakable(true);
        item2.setItemMeta(meta);
        aotv = item2;
    }

    private static void createHype() {
        ItemStack item = new ItemStack(Material.IRON_SWORD, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setUnbreakable(true);
        meta.setDisplayName(ChatColor.LIGHT_PURPLE + "Withered Hyperion " + ChatColor.GOLD + "✪✪✪✪✪");
        List<String> lore = new ArrayList<>();
        lore.add("");
        lore.add("§6Ability: Wither Impact §e§lRIGHT CLICK");
        lore.add("§7Blast 너의 엄마 to shreks ( real ) ( fr ) ");
        meta.setLore(lore);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.addItemFlags(ItemFlag.HIDE_DESTROYS);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        item.setItemMeta(meta);
        hyperionItem = item;
    }

    private static void createBonemerang() {
        customdata += 1;
        ItemStack item = new ItemStack(Material.BONE, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§6Boomerang");
        List<String> lore = new ArrayList<>();
        lore.add(String.valueOf(customdata));
        lore.add("§6LEGENDARY");
        lore.add("§6Boomerang Powers:");
        lore.add("§7Shoots out a boomerang");
        lore.add("§7that deals damage.");
        meta.setLore(lore);
        item.setItemMeta(meta);
        Bonemerang = item;
    }//    private static void createSpaceHelm(){

    //        ItemStack item = new ItemStack(Material.RED_STAINED_GLASS, 1);
//        ItemMeta meta = item.getItemMeta();
//        meta.setUnbreakable(true);
//        meta.setDisplayName(ChatColor.RED + "Dctr's Space Helmet");
//        ArrayList<String> lore = new ArrayList<String>();
//        lore.add(ChatColor.GRAY + "" + ChatColor.ITALIC +"A rare space helmet forged ");
//        lore.add(ChatColor.GRAY + "" + ChatColor.ITALIC + "from shards of moon glass.");
//        lore.add("");
//        lore.add(ChatColor.RESET + "" + ChatColor.GRAY + "To: " + ChatColor.RED + "[SWEAT+]Sweattypalms ");
//        lore.add(ChatColor.RESET + "" + ChatColor.GRAY +"From: " + ChatColor.RED + "[ADMIN] Dctr");
//        lore.add("");
//        lore.add(ChatColor.DARK_GRAY + "Edition #420");
//        lore.add(ChatColor.DARK_GRAY + "December 2021");
//        lore.add("");
//        lore.add(ChatColor.RED + "" + ChatColor.BOLD  + "" + ChatColor.BOLD + "SPECIAL HELMET");
//
//        meta.setLore(lore);
//        item.setItemMeta(meta);
//        spacehelm = item;
//
//    }
    private static void createCanon() {
        ItemStack item = new ItemStack(Material.BLAZE_ROD, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setUnbreakable(true);
        meta.addItemFlags(HIDE_UNBREAKABLE);
        meta.setDisplayName("Canon");
        item.setItemMeta(meta);
        canon = item;

    }

    private static void createTerm() {
        ItemStack item2 = new ItemStack(Material.BOW, 1);
        ItemMeta meta = item2.getItemMeta();
        meta.setUnbreakable(true);
        meta.setDisplayName(ChatColor.LIGHT_PURPLE + "Hasty Terminator " + ChatColor.RED + "✪✪✪✪" + ChatColor.GOLD + "✪");
        List<String> lore = new ArrayList<>();
        lore.add("§7Damage: §c+310 §8(+2,091)");
        lore.add("§7Strength: §c+50 §8(+756)");
        lore.add("");
        lore.add("§6Shortbow: Instantly Shoots");
        lore.add("§7Shoots §b3 §7arrows are once.");
        lore.add("§7Can damage endermen.");
        meta.setLore(lore);
        item2.setItemMeta(meta);
        terminator = item2;
    }


    private static void createAots() {
        ItemStack item3 = new ItemStack(Material.DIAMOND_AXE, 1);
        ItemMeta meta = item3.getItemMeta();
        meta.setUnbreakable(true);
        meta.setDisplayName(ChatColor.GOLD + "Axe of the Shredded");
        item3.setItemMeta(meta);
        aots = item3;

    }

    private static void createSceptre() {
        ItemStack item4 = new ItemStack(Material.ALLIUM, 1);
        ItemMeta meta = item4.getItemMeta();
        meta.setUnbreakable(true);
        meta.setDisplayName("Spirit Sceptre");
        item4.setItemMeta(meta);
        sceptre = item4;

    }

    private static void createProtBar() {
        ItemStack item5 = new ItemStack(Material.ORANGE_TULIP, 1);
        ItemMeta meta = item5.getItemMeta();
        meta.setUnbreakable(true);
        meta.setDisplayName("Protective Barrier");
        item5.setItemMeta(meta);
        protbar = item5;
    }


    @EventHandler
    public void OnRightClick(PlayerInteractEvent e) {
        double radius = 5;
        double radPerSec = 0;
        double radPerTick = radPerSec / 0;
        boolean isRunning = false;
        List<Material> materials = Arrays.asList(Material.RED_STAINED_GLASS, Material.GREEN_STAINED_GLASS, Material.BLUE_STAINED_GLASS, Material.CYAN_STAINED_GLASS, Material.LIGHT_BLUE_STAINED_GLASS, Material.ORANGE_STAINED_GLASS);

        Player p = e.getPlayer();
        World w = p.getWorld();

        Location location = p.getLocation();

        final ItemStack itemstack = p.getInventory().getItemInMainHand();
        if (itemstack.getType().equals(Material.AIR))
            return;
        if (p.getInventory().getItemInMainHand().getType().equals(Material.AIR))
            return;

        //Hyperion
        if (e.getAction().equals(Action.RIGHT_CLICK_AIR) || (e.getAction().equals(Action.RIGHT_CLICK_BLOCK))) {
            if (p.getInventory().getItemInMainHand().getItemMeta().getDisplayName().contains("Hyperion") && intelligence.get(p.getUniqueId()) > 49 || p.getInventory().getItemInMainHand().getItemMeta().getDisplayName().contains("Hyperion") && intelligence.get(p.getUniqueId()) > 49) {
                intelligence.put(p.getUniqueId(), intelligence.get(p.getUniqueId()) - 50);


                p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 5, 1);
                p.spawnParticle(Particle.EXPLOSION_LARGE, p.getLocation(), 1);

                final HashSet<Material> hashSet = new HashSet<Material>();
                hashSet.add(Material.AIR);
                hashSet.add(Material.VOID_AIR);
                double damageCalc = 10000 * (1 + (maxIntelligence.get(p.getUniqueId()) / 100) * 0.3);
                if (p.getLocation().getY() < 250.0D) {
                    Set<Material> transparent = new HashSet<>();
                    transparent.add(Material.AIR);
                    transparent.add(Material.WATER);
                    transparent.add(Material.LAVA);
                    Block b = null;
                    for (Block block : p.getLineOfSight(transparent, 8)) {
                        if (transparent.contains(block.getType()))
                            continue;
                        b = block;
                        break;
                    }
                    if (b == null) {
                        b = p.getLineOfSight(transparent, 8).get(p.getLineOfSight(transparent, 8).size() - 1);
                    } else {
                        p.sendMessage("§cThere are blocks in the way!");
                    }
                    Location loc = new Location(b.getWorld(), b.getX(), (b.getY() + 1), b.getZ(), p.getLocation().getYaw(), p.getLocation().getPitch());
                    p.teleport(loc);
                }



                for (Entity ent : p.getNearbyEntities(10, 10, 10)) {
                    if (ent instanceof Damageable) {
                        m += 1;
                        if (!(ent.getType() == EntityType.PLAYER)) {
                            ((Damageable) ent).damage(damageCalc);
                        }
                    }

                }
                if(m != 0) {
                    p.sendMessage(ChatColor.GRAY + "Your Implosion hit " + ChatColor.RED + m + ChatColor.GRAY + " enemy for " + ChatColor.RED + Math.round(damageCalc) * m + ChatColor.GRAY + " damage.");
                }
                if (p.getInventory().getItemInMainHand().equals(hyperionItem) && intelligence.get(p.getUniqueId()) < 50 || p.getInventory().getItemInMainHand().equals("Hyperion") && intelligence.get(p.getUniqueId()) < 50) {
                    p.sendMessage(ChatColor.RED + "Not enough mana to use the ability.");
                }
                new BukkitRunnable() {
                    public void run() {
                        p.spawnParticle(Particle.HEART, p.getLocation(), 10);
                        p.removePotionEffect(PotionEffectType.ABSORPTION);
                        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1, 2);
                        p.addPotionEffect(PotionEffectType.HEAL.createEffect(0, 8));
                        cancel();
                    }
                }.runTaskTimer(plugin, 101L, 0L);

                if (p.getAbsorptionAmount() == 0) {
                    p.addPotionEffect(PotionEffectType.ABSORPTION.createEffect(100, 5));
                    p.addPotionEffect(PotionEffectType.REGENERATION.createEffect(100, 5));
                    p.playSound(p.getLocation(), Sound.ENTITY_ZOMBIE_VILLAGER_CURE, 1, 2);
                    p.spawnParticle(Particle.SPELL_WITCH, p.getLocation(), 5);
                    m = 0;
                }
            }
        }
        //Terminator
        if (e.getAction().equals(Action.LEFT_CLICK_AIR) || e.getAction().equals(Action.LEFT_CLICK_BLOCK)) {
            if (p.getInventory().getItemInMainHand().getItemMeta().getDisplayName().contains("Terminator")) {
                Arrow arrow = p.launchProjectile(Arrow.class);
                Arrow arrow1 = p.getWorld().spawn(p.getEyeLocation(), Arrow.class);
                Arrow arrow2 = p.getWorld().spawn(p.getEyeLocation(), Arrow.class);

                arrow.setBounce(false);
                arrow1.setBounce(false);
                arrow2.setBounce(false);

                arrow1.setShooter(p);
                arrow2.setShooter(p);
                arrow1.setVelocity(arrow.getVelocity().rotateAroundY(Math.toRadians(8)));
                arrow2.setVelocity(arrow.getVelocity().rotateAroundY(Math.toRadians(-8)));
                w.playSound(location, Sound.ENTITY_ARROW_SHOOT, 1, 1);
                arrow.playEffect(EntityEffect.FIREWORK_EXPLODE);
                arrow1.playEffect(EntityEffect.FIREWORK_EXPLODE);
                arrow2.playEffect(EntityEffect.FIREWORK_EXPLODE);

//                damage
                arrow.setDamage(30000);
                arrow1.setDamage(30000);
                arrow2.setDamage(30000);


                new BukkitRunnable() {
                    public void run() {
                        for (Entity entity : arrow.getLocation().getChunk().getEntities()) {
                            if (arrow.getLocation().distanceSquared(entity.getLocation()) <= 4) {
                                if (entity instanceof Enderman) {
                                    Enderman enderman = (Enderman) entity;
                                    enderman.damage(arrow.getDamage(), p);
                                    arrow.remove();
                                    e.setCancelled(true);


                                }
                            }
                        }
                        for (Entity entity : arrow1.getLocation().getChunk().getEntities()) {
                            if (arrow1.getLocation().distanceSquared(entity.getLocation()) <= 4) {
                                if (entity instanceof Enderman) {
                                    Enderman enderman = (Enderman) entity;
                                    enderman.damage(arrow1.getDamage(), p);
                                    arrow1.remove();
                                    e.setCancelled(true);


                                }
                            }
                        }
                        for (Entity entity : arrow2.getLocation().getChunk().getEntities()) {
                            if (arrow2.getLocation().distanceSquared(entity.getLocation()) <= 4) {
                                if (entity instanceof Enderman) {
                                    Enderman enderman = (Enderman) entity;
                                    enderman.damage(arrow2.getDamage(), p);
                                    arrow2.remove();
                                    e.setCancelled(true);
                                }
                            }
                        }
                        if (arrow.isOnGround()) {
                            arrow.remove();
                        }
                        if (arrow1.isOnGround()) {
                            arrow.remove();
                        }
                        if (arrow2.isOnGround()) {
                            arrow.remove();
                        }
                    }
                }.runTaskTimer(plugin, 0L, 1L);

                e.setCancelled(true);

            }
        }
        if (e.getAction().equals(Action.RIGHT_CLICK_AIR) || e.getAction().equals(Action.RIGHT_CLICK_AIR)) {
            if (p.getInventory().getItemInMainHand().getItemMeta().getDisplayName().contains("Terminator")) {


                Arrow arrow = p.launchProjectile(Arrow.class);

                Arrow arrow1 = p.getWorld().spawn(p.getEyeLocation(), Arrow.class);
                Arrow arrow2 = p.getWorld().spawn(p.getEyeLocation(), Arrow.class);

                arrow1.setShooter(p);
                arrow2.setShooter(p);

                arrow.setBounce(false);
                arrow1.setBounce(false);
                arrow2.setBounce(false);

                arrow1.setVelocity(arrow.getVelocity().rotateAroundY(Math.toRadians(8)));
                arrow2.setVelocity(arrow.getVelocity().rotateAroundY(Math.toRadians(-8)));
                w.playSound(location, Sound.ENTITY_ARROW_SHOOT, 1, 1);
                arrow.playEffect(EntityEffect.FIREWORK_EXPLODE);
                arrow1.playEffect(EntityEffect.FIREWORK_EXPLODE);
                arrow2.playEffect(EntityEffect.FIREWORK_EXPLODE);

                arrow.setDamage(30000);
                arrow1.setDamage(30000);
                arrow2.setDamage(30000);

                //salvation
                if (i >= 3) {
                    ArmorStand as = (ArmorStand) p.getWorld().spawnEntity(p.getLocation().add(0, 1, 0), EntityType.ARMOR_STAND);

                    as.setArms(false);
                    as.setGravity(false);
                    as.setVisible(false);
                    as.setSmall(true);
                    as.setMarker(true);
                    as.setRightArmPose(new EulerAngle(Math.toRadians(90), Math.toRadians(0), Math.toRadians(0)));
                    as.setCollidable(false);

                    Location dest = p.getLocation().add(p.getLocation().getDirection().multiply(10));
                    Vector vector = dest.subtract(p.getLocation()).toVector().multiply(10);

                    new BukkitRunnable() {
                        final int distance = 100;
                        int i = 0;

                        public void run() {
//                            Particle.DustOptions dust = new Particle.DustOptions(
//                                    Color.fromRGB(255, 0, 0), 1);

                            as.getWorld().spawnParticle(Particle.DRIP_LAVA, as.getLocation(), 2);
//                            as.getWorld().spawnParticle(Particle.BLOCK_DUST,as.getLocation(),0,0,0,0,dust);


                            as.teleport(as.getLocation().add(vector.normalize()));
                            for (Entity entity : as.getLocation().getChunk().getEntities()) {
                                if (!as.isDead()) {
                                    if (as.getLocation().distanceSquared(entity.getLocation()) <= 2) {
                                        if (entity != p && entity != as) {
                                            if (entity instanceof LivingEntity) {
                                                LivingEntity livingentity = (LivingEntity) entity;
                                                livingentity.damage(5000000, p);
                                            }
                                        }
                                    }
                                }
                            }
                            i++;
                        }
                    }.runTaskTimer(plugin, 0L, 1L);

                    e.setCancelled(true);
                    i = 0;
                }


                new BukkitRunnable() {
                    public void run() {
                        for (Entity entity : arrow.getLocation().getChunk().getEntities()) {
                            if (arrow.getLocation().distanceSquared(entity.getLocation()) <= 4) {
                                if (entity instanceof Enderman) {
                                    Enderman enderman = (Enderman) entity;
                                    enderman.damage(arrow.getDamage(), p);
                                    arrow.remove();
                                    e.setCancelled(true);


                                }
                            }
                        }
                        for (Entity entity : arrow1.getLocation().getChunk().getEntities()) {
                            if (arrow1.getLocation().distanceSquared(entity.getLocation()) <= 4) {
                                if (entity instanceof Enderman) {
                                    Enderman enderman = (Enderman) entity;
                                    enderman.damage(arrow1.getDamage(), p);
                                    arrow1.remove();
                                    e.setCancelled(true);


                                }
                            }
                        }
                        for (Entity entity : arrow2.getLocation().getChunk().getEntities()) {
                            if (arrow2.getLocation().distanceSquared(entity.getLocation()) <= 4) {
                                if (entity instanceof Enderman) {
                                    Enderman enderman = (Enderman) entity;
                                    enderman.damage(arrow2.getDamage(), p);
                                    arrow2.remove();
                                    e.setCancelled(true);
                                }
                            }
                        }
                        if (arrow.isOnGround()) {
                            arrow.remove();
                        }
                        if (arrow1.isOnGround()) {
                            arrow.remove();
                        }
                        if (arrow2.isOnGround()) {
                            arrow.remove();
                        }
                    }
                }.runTaskTimer(plugin, 0L, 1L);

                e.setCancelled(true);

            }

        }
        //Aots
        if (e.getAction().equals(Action.RIGHT_CLICK_AIR) || e.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
            if (p.getInventory().getItemInMainHand().equals("AOTS") || p.getInventory().getItemInMainHand().equals(aots)) {

                ArmorStand as = (ArmorStand) p.getWorld().spawnEntity(p.getLocation().add(0, 0.5, 0), EntityType.ARMOR_STAND);

                as.setArms(true);
                as.setGravity(false);
                as.setVisible(false);
                as.setSmall(true);
                as.setMarker(true);
                as.setItemInHand(new ItemStack(Material.DIAMOND_AXE));
                as.setRightArmPose(new EulerAngle(Math.toRadians(90), Math.toRadians(0), Math.toRadians(0)));

                Location dest = p.getLocation().add(p.getLocation().getDirection().multiply(10));
                Vector vector = dest.subtract(p.getLocation()).toVector();

                new BukkitRunnable() {
                    final int distance = 30;
                    int i = 0;

                    public void run() {

                        EulerAngle rot = as.getRightArmPose();
                        EulerAngle rotnew = rot.add(20, 0, 0);
                        as.setRightArmPose(rotnew);

                        as.teleport(as.getLocation().add(vector.normalize()));

                        if (as.getTargetBlockExact(1) != null && !as.getTargetBlockExact(1).isPassable()) {
                            if (!as.isDead()) {
                                as.remove();
                                cancel();
                            }
                        }

                        for (Entity entity : as.getLocation().getChunk().getEntities()) {
                            if (!as.isDead()) {
                                if (as.getLocation().distanceSquared(entity.getLocation()) <= 1) {
                                    if (entity != p && entity != as) {
                                        if (entity instanceof LivingEntity) {
                                            LivingEntity livingentity = (LivingEntity) entity;
                                            livingentity.damage(100000, p);
                                            as.remove();
                                            cancel();
                                        }
                                    }
                                }
                            }
                        }

                        if (i > distance) {
                            if (!as.isDead()) {
                                as.remove();
                                cancel();
                            }
                        }

                        i++;
                    }
                }.runTaskTimer(plugin, 0L, 1L);

                e.setCancelled(true);
            }
            //Spirit Sceptre
            if (e.getAction().equals(Action.RIGHT_CLICK_BLOCK) || e.getAction().equals(Action.RIGHT_CLICK_AIR)) {
                if (p.getInventory().getItemInMainHand().equals(sceptre)) {
                    Bat bat = w.spawn(p.getEyeLocation(), Bat.class);
                    //Vector vector2 = new Vector(p.getEyeLocation().getX(), p.getEyeLocation().getY(), p.getEyeLocation().getZ());
                    bat.setVelocity(p.getLocation().getDirection().multiply(6));
                    //bat.setAI(false);

                    for (Entity ent : p.getNearbyEntities(2, 2, 2)) {
                        if (ent != e.getPlayer()) {
                            ent.getWorld().spawnParticle(Particle.EXPLOSION_HUGE, ent.getLocation(), 1);

                            //ent.remove();
                            ((LivingEntity) ent).damage(sceptredmg);

                            Random r1 = new Random();
                            p.sendMessage(ChatColor.GRAY + "Your Bat hit " + ChatColor.RED + "" + ChatColor.GRAY + " enemy for " + ChatColor.RED + r1.nextInt((10000000 - 10000) + 10000) + ChatColor.GRAY + " damage.");
                        }

                    }

                }

            }
            //Protective Barrier
            if (e.getAction().equals(Action.RIGHT_CLICK_AIR) || e.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
                if (p.getInventory().getItemInMainHand().equals("Protective Barrier") || p.getInventory().getItemInMainHand().equals(protbar)) {

                    for (Entity ent : p.getNearbyEntities(5, 5, 5)) {
                        if (p.getLocation().getYaw() >= 0 && p.getLocation().getYaw() <= 40) {
                            Location loc = new Location(w, ent.getLocation().getX(), ent.getLocation().getY(), ent.getLocation().getZ() + 4);
                            ent.teleport(loc);
                        }
                        if (p.getLocation().getYaw() >= 40 && p.getLocation().getYaw() <= 80) {

                            Location loc = new Location(w, ent.getLocation().getX() - 4, ent.getLocation().getY(), ent.getLocation().getZ() + 4);
                            ent.teleport(loc);
                        }
                        if (p.getLocation().getYaw() >= 80 && p.getLocation().getYaw() <= 120) {

                            Location loc = new Location(w, ent.getLocation().getX() - 4, ent.getLocation().getY(), ent.getLocation().getZ());
                            ent.teleport(loc);
                        }
                        if (p.getLocation().getYaw() >= 120 && p.getLocation().getYaw() <= 160) {

                            Location loc = new Location(w, ent.getLocation().getX(), ent.getLocation().getY(), ent.getLocation().getZ() - 4);
                            ent.teleport(loc);
                        }
                        if (p.getLocation().getYaw() >= 160 && p.getLocation().getYaw() <= 180) {

                            Location loc = new Location(w, ent.getLocation().getX() + 1, ent.getLocation().getY(), ent.getLocation().getZ() - 4);
                            ent.teleport(loc);
                        }
                        if (p.getLocation().getYaw() >= -180 && p.getLocation().getYaw() <= -140) {

                            Location loc = new Location(w, ent.getLocation().getX() + 1, ent.getLocation().getY(), ent.getLocation().getZ() - 4);
                            ent.teleport(loc);
                        }
                        if (p.getLocation().getYaw() >= -140 && p.getLocation().getYaw() <= -100) {

                            Location loc = new Location(w, ent.getLocation().getX() + 4, ent.getLocation().getY(), ent.getLocation().getZ() - 1);
                            ent.teleport(loc);
                        }
                        if (p.getLocation().getYaw() >= -100 && p.getLocation().getYaw() <= -60) {

                            Location loc = new Location(w, ent.getLocation().getX() + 4, ent.getLocation().getY(), ent.getLocation().getZ() + 1);
                            ent.teleport(loc);
                        }
                        if (p.getLocation().getYaw() >= -60 && p.getLocation().getYaw() <= -20) {

                            Location loc = new Location(w, ent.getLocation().getX() + 2, ent.getLocation().getY(), ent.getLocation().getZ() + 4);
                            ent.teleport(loc);
                        }
                        if (p.getLocation().getYaw() >= -20 && p.getLocation().getYaw() <= 0) {

                            Location loc = new Location(w, ent.getLocation().getX(), ent.getLocation().getY(), ent.getLocation().getZ() + 4);
                            ent.teleport(loc);
                        }

                    }


                }
            }
            //aotv
            if (e.getAction().equals(Action.RIGHT_CLICK_AIR) || e.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
                if (p.getInventory().getItemInMainHand().equals(aotv)) {
                    float pitch = p.getEyeLocation().getPitch();
                    float yaw = p.getEyeLocation().getYaw();
                    final HashSet<Material> hashSet = new HashSet<Material>();
                    hashSet.add(Material.AIR);


                    final Block block = p.getTargetBlock((Set<Material>) hashSet, 12);

                    final Location playerLocation = p.getLocation();
                    final Location teleportLocation = new Location(block.getWorld(), block.getX(),
                            block.getY(), block.getZ(), playerLocation.getYaw(), playerLocation.getPitch());

                    if (teleportLocation.getBlock().getType() != Material.AIR) {
                        teleportLocation.setY(teleportLocation.getY() + 1);
                        p.getLocation().setYaw(yaw);
                        p.getLocation().setPitch(pitch);
                        p.sendMessage(ChatColor.RED + "There are blocks in the way!");
                    }

                    if (new Location(teleportLocation.getWorld(), teleportLocation.getX(), teleportLocation.getY() + 1,
                            teleportLocation.getZ()).getBlock().getType() == Material.AIR
                            && p.getLocation().add(p.getLocation().getDirection()).getBlock().getType() == Material.AIR) {
                        teleportLocation.setX(teleportLocation.getX() - 0.5D);
                        teleportLocation.setZ(teleportLocation.getZ() - 0.5D);
                        p.getLocation().setYaw(yaw);
                        p.getLocation().setPitch(pitch);
                    } else {
                        teleportLocation.setX(teleportLocation.getX() + 0.5D);
                        teleportLocation.setZ(teleportLocation.getZ() + 0.5D);
                        p.getLocation().setYaw(yaw);
                        p.getLocation().setPitch(pitch);
                    }


                    p.teleport(teleportLocation);

                    p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 5, 1);

                }
            }

            //bonemerang
            if (p.getInventory().getItemInMainHand().equals(Bonemerang)) {

                ArmorStand as = (ArmorStand) p.getWorld().spawnEntity(p.getLocation(), EntityType.ARMOR_STAND);
                ItemStack br = new ItemStack(Material.GHAST_TEAR);
                Location destination = p.getLocation().add(p.getLocation().getDirection().multiply(10));


                as.setArms(true);
                as.setGravity(false);
                as.setVisible(false);
                as.setMarker(true);
                as.setItemInHand(new ItemStack(Material.BONE));
                as.setRightArmPose(new EulerAngle(Math.toRadians(0), Math.toRadians(120), Math.toRadians(0)));

                p.getInventory().removeItem(ItemManager.Bonemerang);
                p.getInventory().setItemInMainHand(br);

                Vector vector = destination.subtract(p.getLocation()).toVector();

                new BukkitRunnable() {

                    final int distance = 20;
                    int i = 0;

                    public void run() {

                        EulerAngle rot = as.getRightArmPose();
                        EulerAngle rotnew = rot.add(0, 10, 0);
                        as.setRightArmPose(rotnew);

                        if (i >= distance) {
                            as.teleport(as.getLocation().subtract(vector.normalize()));
                            if (i >= distance * 2) {
                                as.remove();
                                if (p.getInventory().firstEmpty() != -1) {
                                    p.getInventory().removeItem(br);
                                    p.getInventory().addItem(ItemManager.Bonemerang);
                                } else {
                                    p.getInventory().removeItem(br);
                                    p.getWorld().dropItemNaturally(p.getLocation(), ItemManager.Bonemerang);
                                }
                                cancel();
                            }
                        } else {
                            as.teleport(as.getLocation().add(vector.normalize()));
                        }

                        i++;

                        for (Entity entity : as.getLocation().getChunk().getEntities()) {
                            if (!as.isDead()) {
                                if (as.getLocation().distanceSquared(entity.getLocation()) < 1) {
                                    if (entity != null && entity instanceof Damageable && entity != Bukkit.getServer().getOnlinePlayers()) {
                                        ((Damageable) entity).damage(1);
                                    }
                                }
                            }
                        }

                        if (as.getTargetBlockExact(1) != null && !as.getTargetBlockExact(1).isPassable()) {
                            if (!as.isDead()) {
                                as.remove();
                                if (p.getInventory().firstEmpty() != -1) {
                                    p.getInventory().removeItem(br);
                                    ItemManager.customdata++;
                                    ItemManager.Bonemerang.getItemMeta().setCustomModelData(ItemManager.customdata);
                                    ItemMeta meta = ItemManager.Bonemerang.getItemMeta();
                                    meta.setCustomModelData(ItemManager.customdata);
                                    ItemManager.Bonemerang.setItemMeta(meta);
                                    p.getInventory().addItem(ItemManager.Bonemerang);
                                } else {
                                    p.getInventory().removeItem(br);
                                    p.getWorld().dropItemNaturally(p.getLocation(), ItemManager.Bonemerang);
                                }
                                cancel();
                            }
                        }
                    }
                }.runTaskTimer(plugin, 1L, 1L);

                e.setCancelled(true);
            }


//        if(e.getAction().equals(Action.RIGHT_CLICK_AIR)){
//            if(p.getInventory().getItemInMainHand().equals("Dctr's Space Helmet") || p.getInventory().getItemInMainHand().equals(spacehelm)){
//                init();
//                p.getEquipment().setHelmet(spacehelm);
//                p.sendMessage("Works");
//                p.getInventory().getItemInMainHand().setAmount(p.getInventory().getItemInMainHand().getAmount()-1);
//
//            }
//        }
//        Random random = new Random();
//        if(p.getEquipment().getHelmet().equals("Dctr's Space Helmet") || p.getEquipment().getHelmet().equals(spacehelm)){
//
//            i = Bukkit.getServer().getScheduler().scheduleSyncRepeatingTask(plugin, new Runnable() {
//                @Override
//                public void run() {
//                    int i = random.nextInt(7);
//                    Material randomMat = materials.get(random.nextInt(materials.size()));
//                    p.getEquipment().setHelmet(new ItemStack(randomMat));
//                    if(p.getEquipment().getHelmet().getType().equals(Material.AIR)){
//
//                        Bukkit.getServer().getScheduler().cancelTasks(plugin);
//                    }
//                }
//            }, 0L, 5L);
//
//        }


//    @EventHandler
//    public void onSpaceHelmClick(InventoryClickEvent e1){
//
//        if(e1.getRawSlot() == 5 && e1.getCurrentItem().getType() == (Material.RED_STAINED_GLASS) || e1.getCurrentItem().getType() == (Material.GREEN_STAINED_GLASS) || e1.getCurrentItem().getType() == (Material.BLUE_STAINED_GLASS) || e1.getCurrentItem().getType() == (Material.CYAN_STAINED_GLASS) || e1.getCurrentItem().getType() == (Material.LIGHT_BLUE_STAINED_GLASS) || e1.getCurrentItem().getType() == (Material.ORANGE_STAINED_GLASS)){
//            e1.setCurrentItem(spacehelm);
//
//            Bukkit.getServer().getScheduler().cancelTask(i);
//        }
//
//    }
//    public Location getLocationAroundCircle(Location center, double radius, double angleInRadian) {
//        double x = center.getX() + radius * Math.cos(angleInRadian);
//        double z = center.getZ() + radius * Math.sin(angleInRadian);
//        double y = center.getY();
//
//        Location loc = new Location(center.getWorld(), x, y, z);
//        Vector difference = center.toVector().clone().subtract(loc.toVector()); // this sets the returned location's direction toward the center of the circle
//        loc.setDirection(difference);
//
//        return loc;
//    }
        }


    }


}