package me.skyblockitems.skyblockitems;


import de.tr7zw.nbtapi.NBTItem;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.material.MaterialData;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;

import java.lang.reflect.Field;

import static me.skyblockitems.skyblockitems.ItemManager.hyperionItem;
import static me.skyblockitems.skyblockitems.ItemManager.terminator;


public class ItemFunctions implements Listener {
    private final SkyblockItems plugin = SkyblockItems.getInstance();

    public static NBTItem HyperionNBT = new NBTItem(hyperionItem);
    public static NBTItem TerminatorNBT = new NBTItem(terminator);
    @EventHandler
    public void ItemStats(PlayerJoinEvent e){
        HyperionNBT.setDouble("baseDefense", 4270.0);
        HyperionNBT.setDouble("baseHealth", 0.0);
        HyperionNBT.setDouble("baseIntel", 69420.0);
        TerminatorNBT.setDouble("baseDefense",6900.0);
        TerminatorNBT.setDouble("baseHealth", 0.0);
        TerminatorNBT.setDouble("baseIntel", 9900.0);
    }

    @EventHandler
    public void rightClickFunc(PlayerInteractEvent e){
        Player p = e.getPlayer();
        if(p.getInventory().getItemInMainHand().getType().equals(Material.AIR)) {
            return;
        }
        if (e.getAction().equals(Action.LEFT_CLICK_AIR) || (e.getAction().equals(Action.LEFT_CLICK_BLOCK))) {
            p.getInventory().getItemInMainHand();
            if (p.getInventory().getItemInMainHand().getItemMeta() != null && p.getInventory().getItemInMainHand().getItemMeta().getLore() != null && p.getInventory().getItemInMainHand().equals(ItemManager.Gyrowand)) {
                ArmorStand as = (ArmorStand) p.getWorld().spawnEntity(p.getLocation().add(p.getLocation().getDirection().multiply(4)), EntityType.ARMOR_STAND);
                as.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR, as.getLocation(), 10);
                as.setCustomName("Gyro");
                as.setCustomNameVisible(false);
                as.setArms(false);
                as.setGravity(false);
                as.setVisible(false);
                as.setSmall(true);
                as.setMarker(true);
                as.setCollidable(false);
//                FallingBlock fb = (FallingBlock) as.getWorld().spawnEntity(as.getLocation().add(2,0,0),);
//                as.getWorld().spawnFallingBlock(as.getLocation().add(2,0,0), Material.OBSIDIAN, (byte) 0);
                new BukkitRunnable(){
                    public void run(){
                        FallingBlock line =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(2,0,0), Material.MAGENTA_WOOL, (byte) 0);
                        FallingBlock line1 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(-2,0,0), Material.OBSIDIAN, (byte) 0);
                        FallingBlock line2 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(0,0,2), Material.MAGENTA_WOOL, (byte) 0);
                        FallingBlock line3 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(0,0,-2), Material.OBSIDIAN, (byte) 0);
                        FallingBlock line4 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(1,0,1), Material.PURPLE_CONCRETE, (byte) 0);
                        FallingBlock line5 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(1,0,-1), Material.OBSIDIAN, (byte) 0);
                        FallingBlock line6 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(-1,0,1), Material.MAGENTA_WOOL, (byte) 0);
                        FallingBlock line7 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(-1,0,-1), Material.OBSIDIAN, (byte) 0);
                        line.setDropItem(false);
                        line1.setDropItem(false);
                        line2.setDropItem(false);
                        line3.setDropItem(false);
                        line4.setDropItem(false);
                        line5.setDropItem(false);
                        line6.setDropItem(false);
                        line7.setDropItem(false);
                        new BukkitRunnable(){
                            public void run(){
                                line.remove();
                                line1.remove();
                                line2.remove();
                                line3.remove();
                                line4.remove();
                                line5.remove();
                                line6.remove();
                                line7.remove();
                            }
                        }.runTaskLater(plugin,9L);
                    }
                }.runTaskLater(plugin,7L);

                new BukkitRunnable(){
                    public void run(){
//                        Material air = Material.AIR;
                        FallingBlock line01 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(3,0.5,0), Material.PURPLE_CONCRETE, (byte) 0);
                        FallingBlock line11 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(-3,0.5,0), Material.MAGENTA_WOOL, (byte) 0);
                        FallingBlock line22 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(0,0.5,3), Material.OBSIDIAN, (byte) 0);
                        FallingBlock line33 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(0,0.5,-3), Material.PURPLE_CONCRETE, (byte) 0);
                        FallingBlock line44 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(2,0.5,2), Material.MAGENTA_WOOL, (byte) 0);
                        FallingBlock line55 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(2,0.5,-2), Material.PURPLE_CONCRETE, (byte) 0);
                        FallingBlock line66 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(-2,0.5,2), Material.MAGENTA_WOOL, (byte) 0);
                        FallingBlock line77 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(-2,0.5,-2), Material.OBSIDIAN, (byte) 0);
                        line01.setDropItem(false);
                        line11.setDropItem(false);
                        line22.setDropItem(false);
                        line33.setDropItem(false);
                        line44.setDropItem(false);
                        line55.setDropItem(false);
                        line66.setDropItem(false);
                        line77.setDropItem(false);
                        new BukkitRunnable(){
                            public void run(){
                                line01.remove();
                                line11.remove();
                                line22.remove();
                                line33.remove();
                                line44.remove();
                                line55.remove();
                                line66.remove();
                                line77.remove();
                            }
                        }.runTaskLater(plugin,10L);
                    }
                }.runTaskLater(plugin,2L);
                FallingBlock line100 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(4,1,0), Material.PURPLE_CONCRETE, (byte) 0);
                FallingBlock line200 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(-2,1,0), Material.MAGENTA_WOOL, (byte) 0);
                FallingBlock line300 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(0,1,4), Material.OBSIDIAN, (byte) 0);
                FallingBlock line400 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(0,1,-4), Material.PURPLE_CONCRETE, (byte) 0);
                FallingBlock line500 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(3,1,3), Material.MAGENTA_WOOL, (byte) 0);
                FallingBlock line600 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(3,1,-3), Material.PURPLE_CONCRETE, (byte) 0);
                FallingBlock line700 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(-3,1,3), Material.OBSIDIAN, (byte) 0);
                FallingBlock line800 =  as.getLocation().getWorld().spawnFallingBlock(as.getLocation().add(-3,1,-3), Material.MAGENTA_WOOL, (byte) 0);
                line100.setDropItem(false);
                line200.setDropItem(false);
                line300.setDropItem(false);
                line400.setDropItem(false);
                line500.setDropItem(false);
                line600.setDropItem(false);
                line700.setDropItem(false);
                line800.setDropItem(false);
                new BukkitRunnable(){
                    public void run(){
                        line100.remove();
                        line200.remove();
                        line300.remove();
                        line400.remove();
                        line500.remove();
                        line600.remove();
                        line700.remove();
                        line800.remove();
                    }
                }.runTaskLater(plugin,5L);


                new BukkitRunnable() {

                    public void run() {
                        as.remove();
                    }
                }.runTaskLater(plugin, 30L);
                if(!as.isDead()) {
                    for (Entity ent : as.getNearbyEntities(5, 5, 5)) {
                        if (ent != p && !ent.equals(EntityType.ARMOR_STAND) && !ent.equals(EntityType.PLAYER) && ent != Bukkit.getOnlinePlayers()) {
                            new BukkitRunnable() {
                                public void run() {
                                    if (!ent.getType().equals(EntityType.ARMOR_STAND) && !ent.equals(EntityType.PLAYER) && !ent.getType().equals(EntityType.PLAYER)) {
                                        double random = Math.random() / 2;
                                        ent.teleport(as.getLocation().add(random,random,random));
                                        as.getWorld().spawnParticle(Particle.SPELL_WITCH, as.getLocation(), 2);
                                    }
                                    if(as.isDead()){
                                        cancel();
                                    }
                                }
                            }.runTaskTimer(plugin, 0L, 2L);
                        }
                    }
                }

            }
        }

    }
    @EventHandler
    public void gyroBlock(EntityChangeBlockEvent e){
        Block b = e.getBlock();
        e.setCancelled(true);
    }

}
