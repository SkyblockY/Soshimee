package me.skyblockitems.skyblockitems;

import de.tr7zw.nbtapi.NBTCompound;
import de.tr7zw.nbtapi.NBTItem;
import de.tr7zw.nbtapi.NBTListCompound;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

import static me.skyblockitems.skyblockitems.stats.health;
import static me.skyblockitems.skyblockitems.stats.maxHealth;

public class skyblockMenu implements Listener {

    public static Inventory sbmenu;


    public skyblockMenu(){
        sbmenu = Bukkit.createInventory(null, 54, "Skyblock Menu");
    }
    @EventHandler
    public void invStar(InventoryClickEvent e){
        if(e.getCurrentItem() == null)
            return;
        if(e.getWhoClicked() instanceof Player && e.getCurrentItem().equals(ItemManager.sbmenu)){
            e.getWhoClicked().sendMessage("inv clicked omg?");
            Player p = (Player) e.getWhoClicked();
            p.getInventory().setItem(8, ItemManager.sbmenu);
            if(e.getCurrentItem().equals(ItemManager.sbmenu)){
                e.setCancelled(true);
                p.openInventory(sbmenu);
            }
        }
        if (e.getWhoClicked().getInventory().getItem(8) != ItemManager.sbmenu) {
            Player p = (Player) e.getWhoClicked();
            p.getInventory().setItem(8, ItemManager.sbmenu);
        }


    }
    @EventHandler
    public void invStarRightClick(PlayerInteractEvent e){
        Action a = e.getAction();
        Player p = e.getPlayer();
        if(p.getInventory().getItemInMainHand() == null)
            return;
        if(p.getInventory().getItemInMainHand().equals(ItemManager.sbmenu)){
            if (a == Action.RIGHT_CLICK_AIR) {
                p.openInventory(sbmenu);
            }
            if (a == Action.RIGHT_CLICK_BLOCK) {
                p.openInventory(sbmenu);
            }
            if (a == Action.LEFT_CLICK_AIR) {
                p.openInventory(sbmenu);
            }
        }
//        sb menu itemstacks
        ItemStack Glass = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta meta = Glass.getItemMeta();
        assert meta != null;
        meta.setDisplayName(ChatColor.DARK_GRAY + "");
        Glass.setItemMeta(meta);

        ItemStack Sacks = new ItemStack(Material.PLAYER_HEAD);

        ItemStack Skills = new ItemStack(Material.DIAMOND_SWORD);
        ItemMeta meta2 = Skills.getItemMeta();
        meta2.setDisplayName(ChatColor.GREEN + "Your Skills");
        List<String> lore = new ArrayList<>();
        lore.add("§7View your Skill progression and");
        lore.add("§7Rewards");
        lore.add("§7");
        lore.add("§eClick to View!");
        meta.setLore(lore);
        Skills.setItemMeta(meta2);

        ItemStack Collections = new ItemStack(Material.PAINTING);
        ItemMeta meta4 = Collections.getItemMeta();
        meta4.setDisplayName(ChatColor.GREEN + "Collection");
        lore = new ArrayList<>();
        lore.add("§7View all of the items available");
        lore.add("§7In Skyblock. Collect more of an");
        lore.add("§7item to unlock rewards on your");
        lore.add("§7way to becoming the master of");
        lore.add("§7Skyblock!");
        lore.add("§7");
        lore.add("§eClick to View!");
        meta4.setLore(lore);
        Collections.setItemMeta(meta4);

        ItemStack Trades = new ItemStack(Material.EMERALD);
        ItemMeta meta5 = Trades.getItemMeta();
        meta5.setDisplayName(ChatColor.GREEN + "Trades");
        lore = new ArrayList<>();
        lore.add("§7View your available trades.");
        lore.add("§7These trades are always ");
        lore.add("§7available and accessible through");
        lore.add("§7the Skyblock menu.");
        lore.add("§7");
        lore.add("§eClick to View!");
        meta5.setLore(lore);

        Trades.setItemMeta(meta5);

        ItemStack Recipes = new ItemStack(Material.BOOK);
        ItemMeta meta6 = Recipes.getItemMeta();
        meta6.setDisplayName(ChatColor.GREEN + "Recipe Book");
        lore = new ArrayList<>();
        lore.add("§7Through your adventure, you will");
        lore.add("§7unlock recipes for all kinds of");
        lore.add("§7special items! You can view how");
        lore.add("§7to craft these items here.");
        lore.add("§7");
        lore.add("§eClick to View!");

        meta6.setLore(lore);
        Recipes.setItemMeta(meta6);


        ItemStack Quests = new ItemStack(Material.WRITABLE_BOOK);
        ItemMeta meta7 = Quests.getItemMeta();
        meta7.setDisplayName(ChatColor.GREEN + "Quest Log");
        lore = new ArrayList<>();
        lore.add("§7View your active quests,");
        lore.add("§7progress and rewards.");
        lore.add("§7");
        lore.add("§eClick to View!");
        meta7.setLore(lore);
        Quests.setItemMeta(meta7);

        ItemStack Calender = new ItemStack(Material.CLOCK);
        ItemMeta meta8 = Calender.getItemMeta();
        meta8.setDisplayName(ChatColor.GREEN + "Calendar And Events");
        lore = new ArrayList<>();
        lore.add("§7View the Skyblock calendar,");
        lore.add("§7upcoming events, and event");
        lore.add("§7rewards!");
        lore.add("§7");
        lore.add("§7Next Event: §cNone");
        lore.add("§7");
        lore.add("§eClick to View!");
        meta8.setLore(lore);
        Calender.setItemMeta(meta8);

        ItemStack Storage = new ItemStack(Material.ENDER_CHEST);
        ItemMeta meta9 = Storage.getItemMeta();
        meta9.setDisplayName(ChatColor.GREEN + "Storage");
        Storage.setItemMeta(meta9);

        ItemStack Potions = new ItemStack(Material.GLASS_BOTTLE);
        ItemMeta meta10 = Potions.getItemMeta();
        meta10.setDisplayName(ChatColor.GREEN + "Active Effects");
        Potions.setItemMeta(meta10);

        ItemStack Pets = new ItemStack(Material.BONE);
        ItemMeta meta11 = Pets.getItemMeta();
        meta11.setDisplayName(ChatColor.GREEN + "Pets");
        Pets.setItemMeta(meta11);

        ItemStack Crafting = new ItemStack(Material.CRAFTING_TABLE);
        ItemMeta meta12 = Crafting.getItemMeta();
        meta12.setDisplayName(ChatColor.GREEN + "Crafting Table");
        Crafting.setItemMeta(meta12);

        ItemStack Wardrobe = new ItemStack(Material.LEATHER_CHESTPLATE);
        ItemMeta meta13 = Wardrobe.getItemMeta();
        meta13.setDisplayName(ChatColor.GREEN + "Wardrobe");
        Wardrobe.setItemMeta(meta13);

        ItemStack Bank = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta meta14 = Bank.getItemMeta();
        meta14.setDisplayName(ChatColor.GREEN + "Personal Bank");
        Bank.setItemMeta(meta14);

//        ItemStack GameMenu = new ItemStack(Material.PLAYER_HEAD);
//        ItemMeta meta15 = Bank.getItemMeta();
//        meta15.setDisplayName(ChatColor.GREEN + "Personal Bank");
//        Bank.setItemMeta(meta15);

        ItemStack Profiles = new ItemStack(Material.NAME_TAG);
        ItemMeta meta16 = Profiles.getItemMeta();
        meta16.setDisplayName(ChatColor.GREEN + "Manage Profiles");
        Profiles.setItemMeta(meta16);

        ItemStack BoosterCookie = new ItemStack(Material.COOKIE);
        ItemMeta meta17 = BoosterCookie.getItemMeta();
        meta17.setDisplayName(ChatColor.GOLD + "Booster Cookie");
        BoosterCookie.setItemMeta(meta17);

        ItemStack Settings = new ItemStack(Material.REDSTONE_TORCH);
        ItemMeta meta18 = Settings.getItemMeta();
        meta18.setDisplayName(ChatColor.GREEN + "Settings");
        Settings.setItemMeta(meta18);

        ItemStack PlayerID = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta meta1 = PlayerID.getItemMeta();
        meta1.setDisplayName(ChatColor.GREEN + "Your Skyblock Profile");
        lore = new ArrayList<>();
        e.getPlayer().setMaxHealth(maxHealth.get(p.getUniqueId()));
        health.put(p.getUniqueId(),p.getHealth());
        boolean itemMeta = lore.add((ChatColor.RED + "" + String.format("%.0f", Math.floor(health.get(p.getUniqueId()))) + " ❤"));
        meta1.setLore(lore);
        PlayerID.setItemMeta(meta1);

        ItemStack HypixelID = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta meta19 = HypixelID.getItemMeta();
        meta19.setDisplayName(ChatColor.GREEN + "My Hypixel Profile");
        PlayerID.setItemMeta(meta19);

        ItemStack head123456 = new ItemStack(Material.PLAYER_HEAD, 1, (short) 3);
        NBTItem nbti = new NBTItem(head123456);
        NBTCompound disp = nbti.addCompound("display");
        disp.setString("Name", "Accessory Bag");
        List<String> l = new ArrayList<>();
        l.add(ChatColor.GRAY + "A special bag which can");
        l.add(ChatColor.GRAY + "hold Talismans, Rings");
        l.add(ChatColor.GRAY + "Artifacts and Orbs within");
        l.add(ChatColor.GRAY + "it. All will still work");
        l.add(ChatColor.GRAY + "while in this bag!");
        l.add(ChatColor.GRAY + "");
        l.add(ChatColor.YELLOW + "Click to open!");
        disp.setString("Lore", String.valueOf(l));
        NBTCompound skull = nbti.addCompound("SkullOwner");
        skull.setString("Name", ChatColor.GREEN + "Accessory Bag");
        skull.setString("Id", "fce0323d-7f50-4317-9720-5f6b14cf78ea");
        skull.setString("Lore", String.valueOf(l));
        NBTListCompound texture = skull.addCompound("Properties").getCompoundList("textures").addCompound();
        texture.setString("Signature", "XpRfRz6/vXE6ip7/vq+40H6W70GFB0yjG6k8hG4pmFdnJFR+VQhslE0gXX/i0OAGThcAVSIT+/W1685wUxNofAiy+EhcxGNxNSJkYfOgXEVHTCuugpr+EQCUBI6muHDKms3PqY8ECxdbFTUEuWxdeiJsGt9VjHZMmUukkGhk0IobjQS3hjQ44FiT1tXuUU86oAxqjlKFpXG/iXtpcoXa33IObSI1S3gCKzVPOkMGlHZqRqKKElB54I2Qo4g5CJ+noudIDTzxPFwEEM6XrbM0YBi+SOdRvTbmrlkWF+ndzVWEINoEf++2hkO0gfeCqFqSMHuklMSgeNr/YtFZC5ShJRRv7zbyNF33jZ5DYNVR+KAK9iLO6prZhCVUkZxb1/BjOze6aN7kyN01u3nurKX6n3yQsoQQ0anDW6gNLKzO/mCvoCEvgecjaOQarktl/xYtD4YvdTTlnAlv2bfcXUtc++3UPIUbzf/jpf2g2wf6BGomzFteyPDu4USjBdpeWMBz9PxVzlVpDAtBYClFH/PFEQHMDtL5Q+VxUPu52XlzlUreMHpLT9EL92xwCAwVBBhrarQQWuLjAQXkp3oBdw6hlX6Fj0AafMJuGkFrYzcD7nNr61l9ErZmTWnqTxkJWZfZxmYBsFgV35SKc8rkRSHBNjcdKJZVN4GA+ZQH5B55mi4=");
        texture.setString("Value", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvOTYxYTkxOGMwYzQ5YmE4ZDA1M2U1MjJjYjkxYWJjNzQ2ODkzNjdiNGQ4YWEwNmJmYzFiYTkxNTQ3MzA5ODVmZiJ9fX0===");

        nbti.setInteger("HideFlags", 4);
        nbti.setBoolean("Unbreakable", true);
        head123456 = nbti.getItem();
        ItemMeta talibagmeta = head123456.getItemMeta();
        talibagmeta.setLore(l);
        talibagmeta.setDisplayName(ChatColor.GREEN + "Accessory Bag");
        head123456.setItemMeta(talibagmeta);


//        set item in sbmenu
        sbmenu.setItem(0,  Glass);
        sbmenu.setItem(1,  Glass);
        sbmenu.setItem(2,  Glass);
        sbmenu.setItem(3,  Glass);
        sbmenu.setItem(4,  Glass);
        sbmenu.setItem(5,  Glass);
        sbmenu.setItem(6,  Glass);
        sbmenu.setItem(7,  Glass);
        sbmenu.setItem(8,  Glass);
        sbmenu.setItem(9,  Glass);
        sbmenu.setItem(10, Glass);
        sbmenu.setItem(11, Glass);
        sbmenu.setItem(12, Glass);
        sbmenu.setItem(13, PlayerID);
        sbmenu.setItem(14, Glass);
        sbmenu.setItem(15, Glass);
        sbmenu.setItem(16, Glass);
        sbmenu.setItem(17, Glass);
        sbmenu.setItem(18, Glass);
        sbmenu.setItem(19, Skills);
        sbmenu.setItem(20, Collections);
        sbmenu.setItem(21, Recipes);
        sbmenu.setItem(22, Trades);
        sbmenu.setItem(23, Quests);
        sbmenu.setItem(24, Calender);
        sbmenu.setItem(25, Storage);
        sbmenu.setItem(26, Glass);
        sbmenu.setItem(27, Glass);
        sbmenu.setItem(28, Glass);
        sbmenu.setItem(29, Potions);
        sbmenu.setItem(30, Pets);
        sbmenu.setItem(31, Crafting);
        sbmenu.setItem(32, Wardrobe);
        sbmenu.setItem(33, Bank);
        sbmenu.setItem(34, Glass);
        sbmenu.setItem(35, Glass);
        sbmenu.setItem(36, HypixelID);
        sbmenu.setItem(37, Glass);
        sbmenu.setItem(38, Glass);
        sbmenu.setItem(39, Glass);
        sbmenu.setItem(40, Glass);
        sbmenu.setItem(41, Glass);
        sbmenu.setItem(42, Glass);
        sbmenu.setItem(43, Sacks);
        sbmenu.setItem(44, Sacks);
        sbmenu.setItem(45, head123456);
        sbmenu.setItem(46, Glass);
        sbmenu.setItem(47, PlayerID);
        sbmenu.setItem(48, Profiles);
        sbmenu.setItem(49, BoosterCookie);
        sbmenu.setItem(50, Settings);
        sbmenu.setItem(51, Sacks);
        sbmenu.setItem(52, Sacks);
        sbmenu.setItem(53, Sacks);
    }
    @EventHandler
    public void onInventoryClick(InventoryDragEvent e1) {
        if (e1.getInventory().equals(sbmenu)) {
            e1.setCancelled(true);
        }
    }
    @EventHandler
    public void sbMenuClick(InventoryClickEvent e){
        Player p = (Player) e.getWhoClicked();
        //        sb menu itemstacks
//        Glass Pain ( yesI know I misspelled its on purpose because it is pain)
        ItemStack Glass = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta meta = Glass.getItemMeta();
        assert meta != null;
        meta.setDisplayName(ChatColor.DARK_GRAY + "");
        Glass.setItemMeta(meta);

        ItemStack Sacks = new ItemStack(Material.PLAYER_HEAD);

        ItemStack Skills = new ItemStack(Material.DIAMOND_SWORD);
        ItemMeta meta2 = Skills.getItemMeta();
        meta2.setDisplayName(ChatColor.GREEN + "Your Skills");
        List<String> lore = new ArrayList<>();
        lore.add("§7View your Skill progression and");
        lore.add("§7Rewards");
        lore.add("§7");
        lore.add("§eClick to View!");
        meta.setLore(lore);
        Skills.setItemMeta(meta2);

        ItemStack Collections = new ItemStack(Material.PAINTING);
        ItemMeta meta4 = Collections.getItemMeta();
        meta4.setDisplayName(ChatColor.GREEN + "Collection");
        lore = new ArrayList<>();
        lore.add("§7View all of the items available");
        lore.add("§7In Skyblock. Collect more of an");
        lore.add("§7item to unlock rewards on your");
        lore.add("§7way to becoming the master of");
        lore.add("§7Skyblock!");
        lore.add("§7");
        lore.add("§eClick to View!");
        meta4.setLore(lore);
        Collections.setItemMeta(meta4);

        ItemStack Trades = new ItemStack(Material.EMERALD);
        ItemMeta meta5 = Trades.getItemMeta();
        meta5.setDisplayName(ChatColor.GREEN + "Trades");
        lore = new ArrayList<>();
        lore.add("§7View your available trades.");
        lore.add("§7These trades are always ");
        lore.add("§7available and accessible through");
        lore.add("§7the Skyblock menu.");
        lore.add("§7");
        lore.add("§eClick to View!");
        meta5.setLore(lore);

        Trades.setItemMeta(meta5);

        ItemStack Recipes = new ItemStack(Material.BOOK);
        ItemMeta meta6 = Recipes.getItemMeta();
        meta6.setDisplayName(ChatColor.GREEN + "Recipe Book");
        lore = new ArrayList<>();
        lore.add("§7Through your adventure, you will");
        lore.add("§7unlock recipes for all kinds of");
        lore.add("§7special items! You can view how");
        lore.add("§7to craft these items here.");
        lore.add("§7");
        lore.add("§eClick to View!");

        meta6.setLore(lore);
        Recipes.setItemMeta(meta6);


        ItemStack Quests = new ItemStack(Material.WRITABLE_BOOK);
        ItemMeta meta7 = Quests.getItemMeta();
        meta7.setDisplayName(ChatColor.GREEN + "Quest Log");
        lore = new ArrayList<>();
        lore.add("§7View your active quests,");
        lore.add("§7progress and rewards.");
        lore.add("§7");
        lore.add("§eClick to View!");
        meta7.setLore(lore);
        Quests.setItemMeta(meta7);

        ItemStack Calender = new ItemStack(Material.CLOCK);
        ItemMeta meta8 = Calender.getItemMeta();
        meta8.setDisplayName(ChatColor.GREEN + "Calendar And Events");
        lore = new ArrayList<>();
        lore.add("§7View the Skyblock calendar,");
        lore.add("§7upcoming events, and event");
        lore.add("§7rewards!");
        lore.add("§7");
        lore.add("§7Next Event: §cNone");
        lore.add("§7");
        lore.add("§eClick to View!");
        meta8.setLore(lore);
        Calender.setItemMeta(meta8);

        ItemStack Storage = new ItemStack(Material.ENDER_CHEST);
        ItemMeta meta9 = Storage.getItemMeta();
        meta9.setDisplayName(ChatColor.GREEN + "Storage");
        Storage.setItemMeta(meta9);

        ItemStack Potions = new ItemStack(Material.GLASS_BOTTLE);
        ItemMeta meta10 = Potions.getItemMeta();
        meta10.setDisplayName(ChatColor.GREEN + "Active Effects");
        Potions.setItemMeta(meta10);

        ItemStack Pets = new ItemStack(Material.BONE);
        ItemMeta meta11 = Pets.getItemMeta();
        meta11.setDisplayName(ChatColor.GREEN + "Pets");
        Pets.setItemMeta(meta11);

        ItemStack Crafting = new ItemStack(Material.CRAFTING_TABLE);
        ItemMeta meta12 = Crafting.getItemMeta();
        meta12.setDisplayName(ChatColor.GREEN + "Crafting Table");
        Crafting.setItemMeta(meta12);

        ItemStack Wardrobe = new ItemStack(Material.LEATHER_CHESTPLATE);
        ItemMeta meta13 = Wardrobe.getItemMeta();
        meta13.setDisplayName(ChatColor.GREEN + "Wardrobe");
        Wardrobe.setItemMeta(meta13);

        ItemStack Bank = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta meta14 = Bank.getItemMeta();
        meta14.setDisplayName(ChatColor.GREEN + "Personal Bank");
        Bank.setItemMeta(meta14);

/*
        ItemStack GameMenu = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta meta15 = Bank.getItemMeta();
        meta15.setDisplayName(ChatColor.GREEN + "Personal Bank");
        Bank.setItemMeta(meta15);
*/

        ItemStack Profiles = new ItemStack(Material.NAME_TAG);
        ItemMeta meta16 = Profiles.getItemMeta();
        meta16.setDisplayName(ChatColor.GREEN + "Manage Profiles");
        Profiles.setItemMeta(meta16);

        ItemStack BoosterCookie = new ItemStack(Material.COOKIE);
        ItemMeta meta17 = BoosterCookie.getItemMeta();
        meta17.setDisplayName(ChatColor.GOLD + "Booster Cookie");
        BoosterCookie.setItemMeta(meta17);

        ItemStack Settings = new ItemStack(Material.REDSTONE_TORCH);
        ItemMeta meta18 = Settings.getItemMeta();
        meta18.setDisplayName(ChatColor.GREEN + "Settings");
        Settings.setItemMeta(meta18);

        ItemStack PlayerID = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta meta1 = PlayerID.getItemMeta();
        meta1.setDisplayName(ChatColor.GREEN + "Your Skyblock Profile");
        PlayerID.setItemMeta(meta1);

        ItemStack HypixelID = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta meta19 = HypixelID.getItemMeta();
        meta19.setDisplayName(ChatColor.GREEN + "My Hypixel Profile");
        PlayerID.setItemMeta(meta19);

        ItemStack head123456 = new ItemStack(Material.PLAYER_HEAD, 1, (short) 3);
        NBTItem nbti = new NBTItem(head123456);
        NBTCompound disp = nbti.addCompound("display");
        disp.setString("Name", "Testitem");
//        List<String> l = disp.setString("Lore");
        List<String> l = new ArrayList<>();
        l.add(ChatColor.GRAY + "A special bag which can");
        l.add(ChatColor.GRAY + "hold Talismans, Rings");
        l.add(ChatColor.GRAY + "Artifacts and Orbs within");
        l.add(ChatColor.GRAY + "it. All will still work");
        l.add(ChatColor.GRAY + "while in this bag!");
        l.add(ChatColor.GRAY + "");
        l.add(ChatColor.YELLOW + "Click to open!");

        disp.setString("Lore", String.valueOf(l));
        NBTCompound skull = nbti.addCompound("SkullOwner");
        skull.setString("DisplayName", ChatColor.GREEN + "Accessory Bag");
        skull.setString("Id", "fce0323d-7f50-4317-9720-5f6b14cf78ea");
        skull.setString("Lore", String.valueOf(l));
        NBTListCompound texture = skull.addCompound("Properties").getCompoundList("textures").addCompound();
        texture.setString("Signature", "XpRfRz6/vXE6ip7/vq+40H6W70GFB0yjG6k8hG4pmFdnJFR+VQhslE0gXX/i0OAGThcAVSIT+/W1685wUxNofAiy+EhcxGNxNSJkYfOgXEVHTCuugpr+EQCUBI6muHDKms3PqY8ECxdbFTUEuWxdeiJsGt9VjHZMmUukkGhk0IobjQS3hjQ44FiT1tXuUU86oAxqjlKFpXG/iXtpcoXa33IObSI1S3gCKzVPOkMGlHZqRqKKElB54I2Qo4g5CJ+noudIDTzxPFwEEM6XrbM0YBi+SOdRvTbmrlkWF+ndzVWEINoEf++2hkO0gfeCqFqSMHuklMSgeNr/YtFZC5ShJRRv7zbyNF33jZ5DYNVR+KAK9iLO6prZhCVUkZxb1/BjOze6aN7kyN01u3nurKX6n3yQsoQQ0anDW6gNLKzO/mCvoCEvgecjaOQarktl/xYtD4YvdTTlnAlv2bfcXUtc++3UPIUbzf/jpf2g2wf6BGomzFteyPDu4USjBdpeWMBz9PxVzlVpDAtBYClFH/PFEQHMDtL5Q+VxUPu52XlzlUreMHpLT9EL92xwCAwVBBhrarQQWuLjAQXkp3oBdw6hlX6Fj0AafMJuGkFrYzcD7nNr61l9ErZmTWnqTxkJWZfZxmYBsFgV35SKc8rkRSHBNjcdKJZVN4GA+ZQH5B55mi4=");
        texture.setString("Value", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvOTYxYTkxOGMwYzQ5YmE4ZDA1M2U1MjJjYjkxYWJjNzQ2ODkzNjdiNGQ4YWEwNmJmYzFiYTkxNTQ3MzA5ODVmZiJ9fX0===");
        nbti.setInteger("HideFlags", 4);
        nbti.setBoolean("Unbreakable", true);
        head123456 = nbti.getItem();
        ItemMeta talibagmeta = head123456.getItemMeta();
        talibagmeta.setLore(l);
        talibagmeta.setDisplayName(ChatColor.GREEN + "Accessory Bag");
        head123456.setItemMeta(talibagmeta);


        Inventory enderChest = Bukkit.createInventory(p, 54, "Ender Chest");
//        lores of itemstacks
        if(e.getInventory().equals(sbmenu)){
            e.setCancelled(true);
            if(e.getCurrentItem() == null)
                return;
            if(e.getCurrentItem().equals(Glass)){
                e.setCancelled(true);
            }if(e.getCurrentItem().equals(Sacks)){
                e.setCancelled(true);
                p.sendMessage("Sacks Clicked");
            }if(e.getCurrentItem().equals(Skills)){
                e.setCancelled(true);
                p.sendMessage("Skills Clicked");
            }if(e.getCurrentItem().equals(Collections)){
                e.setCancelled(true);
                p.sendMessage("Collections Clicked");
            }if(e.getCurrentItem().equals(Trades)){
                e.setCancelled(true);
                p.sendMessage("Trades Clicked");
            }if(e.getCurrentItem().equals(Recipes)){
                e.setCancelled(true);
                p.sendMessage("Recipes Clicked");
            }if(e.getCurrentItem().equals(Quests)){
                e.setCancelled(true);
                p.sendMessage("Quests Clicked");
            }if(e.getCurrentItem().equals(Calender)){
                e.setCancelled(true);
                p.sendMessage("Calender Clicked");
            }if(e.getCurrentItem().equals(Storage)){
                e.setCancelled(true);
                p.sendMessage("Storage Clicked");
                p.openInventory(enderChest);
            }if(e.getCurrentItem().equals(Potions)){
                e.setCancelled(true);
                p.sendMessage("Potions Clicked");
            }if(e.getCurrentItem().equals(Pets)){
                e.setCancelled(true);
                p.sendMessage("Pets Clicked");
            }if(e.getCurrentItem().equals(Crafting)){
                e.setCancelled(true);
                p.sendMessage("Crafting Clicked");
            }if(e.getCurrentItem().equals(Wardrobe)){
                e.setCancelled(true);
                p.sendMessage("Wardrobe Clicked");
            }if(e.getCurrentItem().equals(Bank)){
                e.setCancelled(true);
                p.sendMessage("Bank Clicked");
            }if(e.getCurrentItem().equals(HypixelID)){
                e.setCancelled(true);
                p.sendMessage("Warp Clicked");
            }if(e.getCurrentItem().equals(Profiles)){
                e.setCancelled(true);
                p.sendMessage("Profiles Clicked");
            }if(e.getCurrentItem().equals(BoosterCookie)){
                e.setCancelled(true);
                p.sendMessage("BoosterCookie Clicked");
            }if(e.getCurrentItem().equals(Settings)){
                e.setCancelled(true);
                p.sendMessage("Settings Clicked");
            }if(e.getCurrentItem().equals(PlayerID)){
                e.setCancelled(true);
                p.sendMessage("PlayerID Clicked");
            }if(e.getCurrentItem().getItemMeta().getDisplayName().contains(ChatColor.GREEN + "Accessory Bag")){
                e.setCancelled(true);
                p.sendMessage("acecesj[olrujoeilrosoieuioui b ag");
            }
        }
    }

}
