package me.skyblockitems.skyblockitems;

import de.tr7zw.nbtapi.NBTCompound;
import de.tr7zw.nbtapi.NBTCompoundList;
import de.tr7zw.nbtapi.NBTItem;
import de.tr7zw.nbtapi.NBTListCompound;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionType;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scoreboard.*;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.EulerAngle;


import java.awt.*;
import java.sql.SQLOutput;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import java.util.stream.IntStream;

import static me.skyblockitems.skyblockitems.ArmorFunctions.necronChestplateNBT;
import static me.skyblockitems.skyblockitems.ArmorFunctions.necronLeggingNBT;
import static me.skyblockitems.skyblockitems.customMobs.plugin;

public class stats implements Listener {

    private final SkyblockItems plugin = SkyblockItems.getInstance();

    public static HashMap<UUID, Double> maxHealth;
    public static HashMap<UUID, Double> health;
    public static HashMap<UUID, Double> maxIntelligence;
    public static HashMap<UUID, Double> intelligence;
    public static HashMap<UUID, Double> defense;
    public static HashMap<UUID, Double> strength;
    public static HashMap<UUID, Float> speed;
    public static HashMap<UUID, Double> chestplateHealth;
    public static HashMap<UUID, Double> leggingsHealth;
    public static HashMap<UUID, Double> bootsHealth;
    public static HashMap<UUID, Double> chestplateDefense;
    public static HashMap<UUID, Double> leggingsDefense;
    public static HashMap<UUID, Double> bootsDefense;
    public static HashMap<UUID, Double> chestplateIntel;
    public static HashMap<UUID, Double> leggingsIntel;
    public static HashMap<UUID, Double> bootsIntel;
    public static HashMap<UUID, Double> ihHealth;
    public static HashMap<UUID, Double> ihDefense;
    public static HashMap<UUID, Double> ihIntel;
    public static HashMap<UUID, Integer> hype;


    public stats(){
        maxHealth = new HashMap<>();
        health = new HashMap<>();
        maxIntelligence = new HashMap<>();
        intelligence = new HashMap<>();
        defense = new HashMap<>();
        strength = new HashMap<>();
        speed = new HashMap<>();
        chestplateDefense = new HashMap<>();
        leggingsDefense = new HashMap<>();
        bootsDefense = new HashMap<>();
        chestplateHealth = new HashMap<>();
        leggingsHealth = new HashMap<>();
        bootsHealth = new HashMap<>();
        chestplateIntel = new HashMap<>();
        leggingsIntel = new HashMap<>();
        bootsIntel = new HashMap<>();
        ihHealth = new HashMap<>();
        ihDefense = new HashMap<>();
        ihIntel = new HashMap<>();
        hype = new HashMap<>();





    }
    public static double critchance = 30;
    public static double critdamage = 50;
    public static double bonusatkspeed = 0;
    public static double ferocity = 0;


    @EventHandler
    public void setStats(PlayerJoinEvent e){
        Player p = e.getPlayer();
        if(!maxHealth.containsKey(p.getUniqueId()) || !maxIntelligence.containsKey(p.getUniqueId()) || !defense.containsKey(p.getUniqueId()) || !speed.containsKey(p.getUniqueId())) {
            maxHealth.put(p.getUniqueId(), 100.0);
            health.put(p.getUniqueId(), 100.0);
            maxIntelligence.put(p.getUniqueId(), 100.0);
            intelligence.put(p.getUniqueId(), 100.0);
            defense.put(p.getUniqueId(),0.0);
            speed.put(p.getUniqueId(), (float) 1.0);
        }
        if(!chestplateDefense.containsKey(p.getUniqueId()) || !leggingsDefense.containsKey(p.getUniqueId()) || !bootsDefense.containsKey(p.getUniqueId()) || !ihDefense.containsKey(p.getUniqueId())) {
            chestplateDefense.put(p.getUniqueId(),0.0);
            leggingsDefense.put(p.getUniqueId(),0.0);
            bootsDefense.put(p.getUniqueId(), 0.0);
            ihDefense.put(p.getUniqueId(), 0.0);
        }
        if(!chestplateHealth.containsKey(p.getUniqueId()) || !leggingsHealth.containsKey(p.getUniqueId()) || !bootsHealth.containsKey(p.getUniqueId())) {
            chestplateHealth.put(p.getUniqueId(),0.0);
            leggingsHealth.put(p.getUniqueId(),0.0);
            bootsHealth.put(p.getUniqueId(), 0.0);
        }
        if(!chestplateIntel.containsKey(p.getUniqueId()) || !leggingsIntel.containsKey(p.getUniqueId()) || !bootsIntel.containsKey(p.getUniqueId())) {
            chestplateIntel.put(p.getUniqueId(),0.0);
            leggingsIntel.put(p.getUniqueId(),0.0);
            bootsIntel.put(p.getUniqueId(), 0.0);
        }


    }

    @EventHandler
    public void Health(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        new BukkitRunnable(){
            public void run () {
            e.getPlayer().setMaxHealth(maxHealth.get(p.getUniqueId()));
            health.put(p.getUniqueId(), p.getHealth());
            speed.put(p.getUniqueId(), (float) 1.0);
            p.setWalkSpeed(speed.get(p.getUniqueId()));

            e.getPlayer().sendMessage(String.valueOf(e.getPlayer().getHealth()));
            e.getPlayer().getInventory().setItem(8, ItemManager.sbmenu);
            }
        }.runTaskLater(plugin,5L);
//
//        //Scoreboards
//        ScoreboardManager manager = Bukkit.getScoreboardManager();
//        Scoreboard scoreboard = manager.getNewScoreboard();
//
//        Objective objective = scoreboard.registerNewObjective("health", "dummy", "Health");
//        objective.setDisplaySlot(DisplaySlot.SIDEBAR);
//
//        Score score = objective.getScore("Health: " + p.getHealth());
//        p.setScoreboard(scoreboard);


}
    @EventHandler
    public void calcStats(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        p.setAbsorptionAmount(0);
        new BukkitRunnable(){
            public void run () {
            new BukkitRunnable() {
                public void run() {
//                    defense
//                    Double calcd = chestplateDefense.get(p.getUniqueId()) + leggingsDefense.get(p.getUniqueId()) + bootsDefense.get(p.getUniqueId()) + ihDefense.get(p.getUniqueId());
                    if (p.getInventory().getChestplate() == null) {
                        chestplateDefense.put(p.getUniqueId(), 0.0);
                        defense.put(p.getUniqueId(), chestplateDefense.get(p.getUniqueId()) + leggingsDefense.get(p.getUniqueId()) + bootsDefense.get(p.getUniqueId()) + ihDefense.get(p.getUniqueId()));
                    }
                    if (p.getInventory().getLeggings() == null) {
                        leggingsDefense.put(p.getUniqueId(), 0.0);
                        defense.put(p.getUniqueId(), chestplateDefense.get(p.getUniqueId()) + leggingsDefense.get(p.getUniqueId()) + bootsDefense.get(p.getUniqueId()) + ihDefense.get(p.getUniqueId()));
                    }
                    if (p.getInventory().getBoots() == null){
                        bootsDefense.put(p.getUniqueId(), 0.0);
                        defense.put(p.getUniqueId(), chestplateDefense.get(p.getUniqueId()) + leggingsDefense.get(p.getUniqueId()) + bootsDefense.get(p.getUniqueId()) + ihDefense.get(p.getUniqueId()));
                    }
                    if(p.getInventory().getItemInMainHand().getType().equals(Material.AIR)){
                        ihDefense.put(p.getUniqueId(), 0.0);
                        ihHealth.put(p.getUniqueId(), 0.0);
                        ihIntel.put(p.getUniqueId(), 0.0);
                        defense.put(p.getUniqueId(), chestplateDefense.get(p.getUniqueId()) + leggingsDefense.get(p.getUniqueId()) + bootsDefense.get(p.getUniqueId()) + ihDefense.get(p.getUniqueId()));
                    }
                    if (p.getInventory().getChestplate() != null && p.getInventory().getChestplate().getItemMeta() != null && p.getInventory().getChestplate().getItemMeta().getLore() != null) {
                        chestplateDefense.put(p.getUniqueId(), NBTUtils.getDouble(p.getInventory().getChestplate(), "baseDefense"));
                        defense.put(p.getUniqueId(), chestplateDefense.get(p.getUniqueId()) + leggingsDefense.get(p.getUniqueId()) + bootsDefense.get(p.getUniqueId()) + ihDefense.get(p.getUniqueId()));
                    }
                    if (p.getInventory().getLeggings() != null && p.getInventory().getLeggings().getItemMeta() != null && p.getInventory().getLeggings().getItemMeta().getLore() != null) {
                        leggingsDefense.put(p.getUniqueId(), NBTUtils.getDouble(p.getInventory().getLeggings(), "baseDefense"));
                        defense.put(p.getUniqueId(), chestplateDefense.get(p.getUniqueId()) + leggingsDefense.get(p.getUniqueId()) + bootsDefense.get(p.getUniqueId()) + ihDefense.get(p.getUniqueId()));
                    }
                    if (p.getInventory().getBoots() != null && p.getInventory().getBoots().getItemMeta() != null && p.getInventory().getBoots().getItemMeta().getLore() != null) {
                        bootsDefense.put(p.getUniqueId(), NBTUtils.getDouble(p.getInventory().getBoots(), "baseDefense"));
                        defense.put(p.getUniqueId(), chestplateDefense.get(p.getUniqueId()) + leggingsDefense.get(p.getUniqueId()) + bootsDefense.get(p.getUniqueId()) + ihDefense.get(p.getUniqueId()));
                    }
                    if(p.getInventory().getItemInMainHand().getType() != Material.AIR && p.getInventory().getItemInMainHand().getItemMeta() != null && p.getInventory().getItemInMainHand().getItemMeta().getLore() != null){
                        ihDefense.put(p.getUniqueId(), NBTUtils.getDouble(p.getInventory().getItemInMainHand(), "baseDefense"));
                        defense.put(p.getUniqueId(), chestplateDefense.get(p.getUniqueId()) + leggingsDefense.get(p.getUniqueId()) + bootsDefense.get(p.getUniqueId()) + ihDefense.get(p.getUniqueId()));
                    }
//                    health
                    if (p.getInventory().getChestplate() == null) {
                        chestplateHealth.put(p.getUniqueId(), 0.0);
                        maxHealth.put(p.getUniqueId(),100+ chestplateHealth.get(p.getUniqueId()) + leggingsHealth.get(p.getUniqueId()) + bootsHealth.get(p.getUniqueId()));
                    }
                    if (p.getInventory().getLeggings() == null) {
                        leggingsHealth.put(p.getUniqueId(), 0.0);
                        maxHealth.put(p.getUniqueId(),100 +chestplateHealth.get(p.getUniqueId()) + leggingsHealth.get(p.getUniqueId()) + bootsHealth.get(p.getUniqueId()));
                    }
                    if (p.getInventory().getBoots() == null){
                        bootsHealth.put(p.getUniqueId(), 0.0);
                        maxHealth.put(p.getUniqueId(),100+ chestplateHealth.get(p.getUniqueId()) + leggingsHealth.get(p.getUniqueId()) + bootsHealth.get(p.getUniqueId()));
                    }
                    if (p.getInventory().getChestplate() != null && p.getInventory().getChestplate().getItemMeta() != null && p.getInventory().getChestplate().getItemMeta().getLore() != null) {
                        chestplateHealth.put(p.getUniqueId(), NBTUtils.getDouble(p.getInventory().getChestplate(), "baseHealth"));
                        maxHealth.put(p.getUniqueId(),100+ chestplateHealth.get(p.getUniqueId()) + leggingsHealth.get(p.getUniqueId()) + bootsHealth.get(p.getUniqueId()));
                    }
                    if (p.getInventory().getLeggings() != null && p.getInventory().getLeggings().getItemMeta() != null && p.getInventory().getLeggings().getItemMeta().getLore() != null) {
                        leggingsHealth.put(p.getUniqueId(), NBTUtils.getDouble(p.getInventory().getLeggings(), "baseHealth"));
                        maxHealth.put(p.getUniqueId(),100 + chestplateHealth.get(p.getUniqueId()) + leggingsHealth.get(p.getUniqueId()) + bootsHealth.get(p.getUniqueId()));
                    }
                    if (p.getInventory().getBoots() != null && p.getInventory().getBoots().getItemMeta() != null && p.getInventory().getBoots().getItemMeta().getLore() != null) {
                        bootsHealth.put(p.getUniqueId(), NBTUtils.getDouble(p.getInventory().getBoots(), "baseHealth"));
                        maxHealth.put(p.getUniqueId(),100+ chestplateHealth.get(p.getUniqueId()) + leggingsHealth.get(p.getUniqueId()) + bootsHealth.get(p.getUniqueId()));
                    }
                    if(p.getInventory().getItemInMainHand().getType() != Material.AIR && p.getInventory().getItemInMainHand().getItemMeta() != null && p.getInventory().getItemInMainHand().getItemMeta().getLore() != null){
                        ihHealth.put(p.getUniqueId(), NBTUtils.getDouble(p.getInventory().getItemInMainHand(), "baseHealth"));
                        maxHealth.put(p.getUniqueId(), 100 +  chestplateHealth.get(p.getUniqueId()) + leggingsHealth.get(p.getUniqueId()) + bootsHealth.get(p.getUniqueId()) + ihHealth.get(p.getUniqueId()));
                    }
//                    intel
                    if (p.getInventory().getChestplate() == null) {
                        chestplateIntel.put(p.getUniqueId(), 0.0);
                        maxIntelligence.put(p.getUniqueId(),100+ chestplateIntel.get(p.getUniqueId()) + leggingsIntel.get(p.getUniqueId()) + bootsIntel.get(p.getUniqueId()));
                    }
                    if (p.getInventory().getLeggings() == null) {
                        leggingsIntel.put(p.getUniqueId(), 0.0);
                        maxIntelligence.put(p.getUniqueId(),100 +chestplateIntel.get(p.getUniqueId()) + leggingsIntel.get(p.getUniqueId()) + bootsIntel.get(p.getUniqueId()));
                    }
                    if (p.getInventory().getBoots() == null){
                        bootsIntel.put(p.getUniqueId(), 0.0);
                        maxIntelligence.put(p.getUniqueId(),100+ chestplateIntel.get(p.getUniqueId()) + leggingsIntel.get(p.getUniqueId()) + bootsIntel.get(p.getUniqueId()));
                    }
                    if (p.getInventory().getChestplate() != null && p.getInventory().getChestplate().getItemMeta() != null && p.getInventory().getChestplate().getItemMeta().getLore() != null) {
                        chestplateIntel.put(p.getUniqueId(), NBTUtils.getDouble(p.getInventory().getChestplate(), "baseIntel"));
                        maxIntelligence.put(p.getUniqueId(),100+ chestplateIntel.get(p.getUniqueId()) + leggingsIntel.get(p.getUniqueId()) + bootsIntel.get(p.getUniqueId()));
                    }
                    if (p.getInventory().getLeggings() != null && p.getInventory().getLeggings().getItemMeta() != null && p.getInventory().getLeggings().getItemMeta().getLore() != null) {
                        leggingsIntel.put(p.getUniqueId(), NBTUtils.getDouble(p.getInventory().getLeggings(), "baseIntel"));
                        maxIntelligence.put(p.getUniqueId(),100 + chestplateIntel.get(p.getUniqueId()) + leggingsIntel.get(p.getUniqueId()) + bootsIntel.get(p.getUniqueId()));
                    }
                    if (p.getInventory().getBoots() != null && p.getInventory().getBoots().getItemMeta() != null && p.getInventory().getBoots().getItemMeta().getLore() != null) {
                        bootsIntel.put(p.getUniqueId(), NBTUtils.getDouble(p.getInventory().getBoots(), "baseIntel"));
                        maxIntelligence.put(p.getUniqueId(),100+ chestplateIntel.get(p.getUniqueId()) + leggingsIntel.get(p.getUniqueId()) + bootsIntel.get(p.getUniqueId()));
                    }
                    if(p.getInventory().getItemInMainHand().getType() != Material.AIR && p.getInventory().getItemInMainHand().getItemMeta() != null && p.getInventory().getItemInMainHand().getItemMeta().getLore() != null){
                        ihIntel.put(p.getUniqueId(), NBTUtils.getDouble(p.getInventory().getItemInMainHand(), "baseIntel"));
                        maxIntelligence.put(p.getUniqueId(),100 + chestplateIntel.get(p.getUniqueId()) + leggingsIntel.get(p.getUniqueId()) + bootsIntel.get(p.getUniqueId()) + ihIntel.get(p.getUniqueId()));
                    }

                }
            }.runTaskTimer(plugin, 0L, 1L);
        }
        }.runTaskLater(plugin,10L);

    }
    @EventHandler
    public void showStats(PlayerJoinEvent e){
        Player p = e.getPlayer();
        p.setHealthScale(40);
        new BukkitRunnable(){
            public void run() {
                e.getPlayer().setMaxHealth(maxHealth.get(p.getUniqueId()));
                health.put(p.getUniqueId(),p.getHealth());
                p.setSaturation(100);
                p.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(ChatColor.RED+ "" + String.format("%.0f",Math.floor(health.get(p.getUniqueId()))) + "/" + String.format("%.0f",maxHealth.get(p.getUniqueId())) + " ❤      " + ChatColor.GREEN + " " + String.format("%.0f",defense.get(p.getUniqueId())) + " ❈ " + "     " + ChatColor.AQUA + "" + String.format("%.0f",intelligence.get(p.getUniqueId())) + "/" + String.format("%.0f",maxIntelligence.get(p.getUniqueId())) + "✎"));
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }
    @EventHandler
    public void regenIntelligence(PlayerJoinEvent e){
        Player p = e.getPlayer();
        new BukkitRunnable(){
            public void run() {
//              double calculatedInt = maxIntelligence.get(p.getUniqueId()) + (maxIntelligence.get(p.getUniqueId()) * 20 / 100);
                double calculatedInt = maxIntelligence.get(p.getUniqueId()) * 20 / 100;

                intelligence.put(p.getUniqueId(),intelligence.get(p.getUniqueId()) + calculatedInt);


                if(intelligence.get(p.getUniqueId()) >= maxIntelligence.get(p.getUniqueId())){
                    intelligence.put(p.getUniqueId(), maxIntelligence.get(p.getUniqueId()));
                }

                if(intelligence.get(p.getUniqueId()) < 0){
                    intelligence.put(p.getUniqueId(), 0.0);
                }


            }
        }.runTaskTimer(plugin, 0L, 20L);
    }
    @EventHandler
    public void regenHealth(PlayerJoinEvent e){
        Player p = e.getPlayer();
         new BukkitRunnable(){
             public void run(){
                 if(!p.isDead()){
                     double calculatedInt = maxHealth.get(p.getUniqueId()) * 1/100;
                     if(health.get(p.getUniqueId()) + calculatedInt < maxHealth.get(p.getUniqueId())){
                         health.put(p.getUniqueId(), health.get(p.getUniqueId()) + calculatedInt);
                         p.setHealth(health.get(p.getUniqueId()));

                     }
                     if(health.get(p.getUniqueId()) + calculatedInt > maxHealth.get(p.getUniqueId())){
                         health.put(p.getUniqueId(),maxHealth.get(p.getUniqueId()));
                         p.setHealth(health.get(p.getUniqueId()));

                     }
                 }
             }
         }.runTaskTimer(plugin, 0L, 20L);
    }
    @EventHandler
    public void noPvp(EntityDamageByEntityEvent e){
        if(!(e.getDamager() instanceof Player))
            return;
        if(!(e.getEntity() instanceof Player))
            return;

        e.setCancelled(true);
    }
    @EventHandler
    public void noPvp1(EntityDamageByEntityEvent e) {
        // Is target a player, if not stop
        Entity damagee = e.getEntity();
        if(!(e.getEntity() instanceof Player))
            return;
        // Is damager an arrow, if not stop
        if (!(e.getDamager() instanceof Arrow))
            return;
        // Is shooter a player, if not stop
        ProjectileSource src = ((Arrow) e.getDamager()).getShooter();
        if (src instanceof Player)
        e.setCancelled(true);

//        Player damager = (Player) src;
    }
    @EventHandler
    public void dingSound(EntityDamageByEntityEvent e){
        if(!(e.getEntity() instanceof Player) ) {
            if(e.getDamager() instanceof Player || e.getDamager() instanceof Arrow){
            if(e.getDamager() instanceof Player){
                Player p = (Player) e.getDamager();
                p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 10, 1);
            }
            if(e.getDamager() instanceof Arrow) {
                ProjectileSource src = ((Arrow) e.getDamager()).getShooter();
                if (src instanceof Player) {
                    Player pla = (Player) src;
                    pla.playSound(pla.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 10, 1);
                }

            }            }
        }
    }
    @EventHandler
    public void showDamage(EntityDamageByEntityEvent e){
        Entity ent = e.getEntity();
//        Player p = (Player) e.getDamager();
        if(e.getDamager() instanceof Player){
            ArmorStand as = (ArmorStand) ent.getWorld().spawnEntity(ent.getLocation().add(ent.getLocation().getDirection().multiply(0.2)).add(0,1,0), EntityType.ARMOR_STAND);
            String dmg = String.valueOf((int) e.getDamage());
            String actualDmg = "";
            for(int i = 0; i < dmg.length(); i++){
                if(i % 4 == 0){
                    actualDmg += "§f" + Character.digit(dmg.charAt(i), 10);
                }
                if(i % 4 == 1){
                    actualDmg += "§e" + Character.digit(dmg.charAt(i), 10);
                }
                if(i % 4 == 2){
                    actualDmg += "§6" + Character.digit(dmg.charAt(i), 10);

                }
                if(i % 4 == 2){
                    actualDmg += "§c" + Character.digit(dmg.charAt(i), 10);

                }
            }
            String star = "§f ✧ ";
            as.setCustomName(star + actualDmg + ChatColor.WHITE + " ✧");
            as.setCustomNameVisible(true);
            as.setArms(false);
            as.setGravity(false);
            as.setVisible(false);
            as.setSmall(true);
            as.setMarker(true);
            as.setCollidable(false);
            new BukkitRunnable(){
                public void run(){
                    as.remove();
                }
            }.runTaskLater(plugin,20L);
        }
        if (e.getDamager() instanceof Arrow) {
            // Is shooter a player, if not stop
            ProjectileSource src = ((Arrow) e.getDamager()).getShooter();
            if (!(src instanceof Player))
                return;
            if (e.getEntity() instanceof Player)
                return;
            Player damager = (Player) src;

            ArmorStand as = (ArmorStand) ent.getWorld().spawnEntity(ent.getLocation().add(ent.getLocation().getDirection().multiply(0.2)).add(0,1,0), EntityType.ARMOR_STAND);
            String dmg = String.valueOf((int) e.getDamage());
            String actualDmg = "";
            for(int i = 0; i < dmg.length(); i++){
                if(i % 4 == 0){
                    actualDmg += "§f" + Character.digit(dmg.charAt(i), 10);
                }
                if(i % 4 == 1){
                    actualDmg += "§e" + Character.digit(dmg.charAt(i), 10);
                }
                if(i % 4 == 2){
                    actualDmg += "§6" + Character.digit(dmg.charAt(i), 10);

                }
                if(i % 4 == 2){
                    actualDmg += "§c" + Character.digit(dmg.charAt(i), 10);

                }
            }
            String star = "§f ✧ ";
            as.setCustomName(star + actualDmg + ChatColor.WHITE + " ✧");
            as.setCustomNameVisible(true);
            as.setArms(false);
            as.setGravity(false);
            as.setVisible(false);
            as.setSmall(true);
            as.setMarker(true);
            as.setCollidable(false);
            new BukkitRunnable(){
                public void run(){
                    as.remove();
                }
            }.runTaskLater(plugin,20L);
        }
    }
    @EventHandler
    public void ferocity(EntityDamageByEntityEvent e){
        if(e.getDamager() instanceof Player || e.getDamager() instanceof Arrow)

        if(e.getDamager() instanceof Player) {
            if (e.getEntity() instanceof Player)
                return;


            Double dmg = e.getDamage();
            Entity ent = e.getEntity();
            Player player = (Player) e.getDamager();


            ArmorStand as = (ArmorStand) ent.getWorld().spawnEntity(ent.getLocation().add(ent.getLocation().getDirection().multiply(0.2)).add(0,1,0), EntityType.ARMOR_STAND);
            String dmg1 = String.valueOf((int) e.getDamage());
            String actualDmg = "";
            for(int i = 0; i < dmg1.length(); i++){
                if(i % 4 == 0){
                    actualDmg += "§f" + Character.digit(dmg1.charAt(i), 10);
                }
                if(i % 4 == 1){
                    actualDmg += "§e" + Character.digit(dmg1.charAt(i), 10);
                }
                if(i % 4 == 2){
                    actualDmg += "§6" + Character.digit(dmg1.charAt(i), 10);

                }
                if(i % 4 == 3){
                    actualDmg += "§c" + Character.digit(dmg1.charAt(i), 10);

                }
            }
            String star = "§f ✧ ";
            as.setCustomName(star + actualDmg + ChatColor.WHITE + " ✧");
            as.setCustomNameVisible(true);
            as.setArms(false);
            as.setGravity(false);
            as.setVisible(false);
            as.setSmall(true);
            as.setMarker(true);
            as.setCollidable(false);
            new BukkitRunnable(){
                public void run(){
                    as.remove();
                }
            }.runTaskLater(plugin,20L);


            new BukkitRunnable() {
                public void run() {
//                    ((Damageable) ent).damage(dmg);
                    ((Damageable) ent).damage(dmg,  player);
                    if(((Damageable) ent).getHealth() - dmg > 0) {
                        ((Damageable) ent).setHealth(((Damageable) ent).getHealth() - dmg);
                    }else if(((Damageable) ent).getHealth() - dmg <= 0){
                        ((Damageable) ent).setHealth(0);
                    }
                    new BukkitRunnable() {
                        public void run() {
                            player.playSound(player.getLocation(), Sound.BLOCK_FIRE_AMBIENT, 1, 1);
                        }
                    }.runTaskLater(plugin, 4L);
                    new BukkitRunnable() {
                        public void run() {
                            player.playSound(player.getLocation(), Sound.ENTITY_ZOMBIE_STEP, 1, 1);
                            player.playSound(player.getLocation(), Sound.BLOCK_FIRE_EXTINGUISH, 0.1f, 1);
                            player.playSound(player.getLocation(), Sound.ENTITY_ZOMBIE_BREAK_WOODEN_DOOR, 1, 1);
                        }
                    }.runTaskLater(plugin, 2L);
                }
            }.runTaskLater(plugin, 10L);
        }
        if(e.getDamager() instanceof Arrow){
            ProjectileSource src = ((Arrow) e.getDamager()).getShooter();
            if (!(src instanceof Player))
                return;
            if (e.getEntity() instanceof Player)
                return;
            Player player = (Player) src;
            Double dmg = e.getDamage();
            Entity ent = e.getEntity();

            ArmorStand as = (ArmorStand) ent.getWorld().spawnEntity(ent.getLocation().add(ent.getLocation().getDirection().multiply(0.2)).add(0,1,0), EntityType.ARMOR_STAND);
            String dmg1 = String.valueOf((int) e.getDamage());
            String actualDmg = "";
            for(int i = 0; i < dmg1.length(); i++){
                if(i % 4 == 0){
                    actualDmg += "§f" + Character.digit(dmg1.charAt(i), 10);
                }
                if(i % 4 == 1){
                    actualDmg += "§e" + Character.digit(dmg1.charAt(i), 10);
                }
                if(i % 4 == 2){
                    actualDmg += "§6" + Character.digit(dmg1.charAt(i), 10);

                }
                if(i % 4 == 3){
                    actualDmg += "§c" + Character.digit(dmg1.charAt(i), 10);

                }
            }
            String star = "§f ✧ ";
            as.setCustomName(star + actualDmg + ChatColor.WHITE + " ✧");
            as.setCustomNameVisible(true);
            as.setArms(false);
            as.setGravity(false);
            as.setVisible(false);
            as.setSmall(true);
            as.setMarker(true);
            as.setCollidable(false);
            new BukkitRunnable(){
                public void run(){
                    as.remove();
                }
            }.runTaskLater(plugin,20L);


            new BukkitRunnable() {
                public void run() {
                    ((Damageable) ent).damage(dmg,  player);
                    if(((Damageable) ent).getHealth() - dmg > 0) {
                        ((Damageable) ent).setHealth(((Damageable) ent).getHealth() - dmg);
                    }else if(((Damageable) ent).getHealth() - dmg <= 0){
                        ((Damageable) ent).setHealth(0);
                    }
                    new BukkitRunnable() {
                        public void run() {
                            player.playSound(player.getLocation(), Sound.BLOCK_FIRE_AMBIENT, 1, 1);
                        }
                    }.runTaskLater(plugin, 4L);
                    new BukkitRunnable() {
                        public void run() {
                            player.playSound(player.getLocation(), Sound.ENTITY_ZOMBIE_STEP, 1, 1);
                            player.playSound(player.getLocation(), Sound.BLOCK_FIRE_EXTINGUISH, 0.1f, 1);
                            player.playSound(player.getLocation(), Sound.ENTITY_ZOMBIE_BREAK_WOODEN_DOOR, 1, 1);
                        }
                    }.runTaskLater(plugin, 2L);
                }
            }.runTaskLater(plugin, 10L);
        }

    }

}
