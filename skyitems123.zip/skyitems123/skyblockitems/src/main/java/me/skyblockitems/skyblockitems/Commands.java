package me.skyblockitems.skyblockitems;

//import com.sun.tools.javac.jvm.Items;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageByBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;
import org.spigotmc.event.player.PlayerSpawnLocationEvent;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import static me.skyblockitems.skyblockitems.ArmorFunctions.adminBootNBT;
import static me.skyblockitems.skyblockitems.customMobs.plugin;
import static me.skyblockitems.skyblockitems.stats.*;

public class Commands implements CommandExecutor{

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String s, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage("This Plugin Works!");
            return true;
        }

//        if (sender.hasPermission("op")) {

            Player player = (Player) sender;

            if (cmd.getName().equalsIgnoreCase("boss1")) {
                Giant zombie = player.getWorld().spawn(player.getLocation(), Giant.class);
                zombie.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(400000);
                zombie.setHealth(400000);
                zombie.setCustomName("Health: " + zombie.getHealth());
                zombie.getEquipment().setBoots(new ItemStack(Material.DIAMOND_BOOTS));
                zombie.getEquipment().setHelmet(new ItemStack(Material.DIAMOND_HELMET));
                zombie.getEquipment().setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
                zombie.getEquipment().setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));
            }

            if (cmd.getName().equalsIgnoreCase("itemsgui")) {
                player.sendMessage("opened: " + ChatColor.RED + "Skyblock Items GUI");
                GuiClass gc = new GuiClass();
                player.openInventory(GuiClass.inv);
            }
            if (cmd.getName().equalsIgnoreCase("blackStorm")) {

                player.getEquipment().setChestplate(blackArmor.chest());
                player.getEquipment().setLeggings(blackArmor.leggings());
                player.getEquipment().setBoots(blackArmor.boots());
            }
            if (cmd.getName().equalsIgnoreCase("storm")) {
                player.getEquipment().setChestplate(stormArmor.chest());
                player.getEquipment().setLeggings(stormArmor.leggings());
                player.getEquipment().setBoots(stormArmor.boots());
            }
            if (cmd.getName().equalsIgnoreCase("craft")) {
                player.openWorkbench(null, true);
            }
            if (cmd.getName().equalsIgnoreCase("hub")) {
                Bukkit.getServer().getWorld("world").setSpawnLocation(-4, 70,196);
                Location loc = new Location(Bukkit.getServer().getWorld("world"), Bukkit.getServer().getWorld("world").getSpawnLocation().getX(), Bukkit.getServer().getWorld("world").getSpawnLocation().getY(), Bukkit.getServer().getWorld("world").getSpawnLocation().getZ());
                player.sendMessage(ChatColor.GREEN + "Successfully teleported to the Hub.");

                player.teleport(loc, PlayerTeleportEvent.TeleportCause.PLUGIN);
            }
            if (cmd.getName().equalsIgnoreCase("enchant")) {
                player.openEnchanting(null, true);
            }
            if (cmd.getName().equalsIgnoreCase("enderchest")) {
                Inventory enderchest = Bukkit.createInventory(player, 54, ChatColor.BLACK + ("Ender Chest"));

                ItemStack close = new ItemStack(Material.BARRIER, 1);

                ItemMeta close_meta = close.getItemMeta();
                close_meta.setDisplayName(ChatColor.DARK_RED + "CLOSE");
                close.setItemMeta(close_meta);


                enderchest.addItem(close);
                player.openInventory(enderchest);
            }
            if (cmd.getName().equalsIgnoreCase("owner")) {
                if (player.getDisplayName().equalsIgnoreCase("Sweattypalms")) {
                    player.setDisplayName(ChatColor.RED + "[OWNER] Sweattypalms" + ChatColor.WHITE);
                    player.setPlayerListName(ChatColor.RED + "[OWNER] Sweattypalms" + ChatColor.WHITE);
                } else {
                    player.sendMessage(ChatColor.RED + "Cope harder.");
                }
            }
            if (cmd.getName().equalsIgnoreCase("admin")) {
                if (player.getDisplayName().equalsIgnoreCase("56__")) {
                    player.setDisplayName(ChatColor.RED + "[ADMIN] 56__" + ChatColor.WHITE);
                    player.setPlayerListName(ChatColor.RED + "[ADMIN] 56__" + ChatColor.WHITE);
                }
                if (player.getDisplayName().equalsIgnoreCase("JLMR_")) {
                    player.setDisplayName(ChatColor.LIGHT_PURPLE + "[Professional Noob] JLMR_");
                    player.setPlayerListName(ChatColor.LIGHT_PURPLE + "[Professional Noob] JLMR_");
                }
                if (player.getUniqueId().equals("ec0f0d6c-04c3-43bd-bf4a-7879f11ea261")) {
                    player.sendMessage("Owner better. IMO. But here you go anyways :(");
                    player.setDisplayName(ChatColor.RED + "[ADMIN] Sweattypalms" + ChatColor.WHITE);
                } else {
                    player.sendMessage(ChatColor.RED + "You are not Allowed to use this command. Ask permission from the owner of the server.");
                }
            }
            if (cmd.getName().equalsIgnoreCase("skyblockmenu")) {
                player.getInventory().setItem(8, ItemManager.sbmenu);
            }
            if (cmd.getName().equalsIgnoreCase("showStats")) {
                player.sendMessage(ChatColor.RED + "Max Health: " + ChatColor.GREEN + "" + maxHealth.get(player.getUniqueId()));
                player.sendMessage(ChatColor.RED + "Health: " + ChatColor.GREEN + "" + health.get(player.getUniqueId()));
                player.sendMessage(ChatColor.RED + "Max Intelligence: " + ChatColor.GREEN + "" + maxIntelligence.get(player.getUniqueId()));
                player.sendMessage(ChatColor.RED + "Intelligence: " + ChatColor.GREEN + "" + intelligence.get(player.getUniqueId()));
                player.sendMessage(ChatColor.RED + "Speed: " + ChatColor.GREEN + "" + player.getWalkSpeed());
                player.sendMessage(String.valueOf(player.getHealth()));
            }
            if (cmd.getName().equalsIgnoreCase("telekinesis")) {
                player.getInventory().getItemInMainHand().addUnsafeEnchantment(CustomEnchants.TELEKINESIS, 1);
//            player.getInventory().getItemInMainHand().addUnsafeEnchantment(Enchantment.DIG_SPEED, 100);
                player.sendMessage("Telekinesis Applied to your Tool.");
            }
            if (cmd.getName().equalsIgnoreCase("summonZombie")) {
                customMobs.summonZombie(player.getLocation());
            }if (cmd.getName().equalsIgnoreCase("summonNecron")) {
                customMobs.summonNecron(player.getLocation());
            }if(cmd.getName().equalsIgnoreCase("adminboots")){
                player.getInventory().addItem(adminBootNBT.getItem());
            }if(cmd.getName().equalsIgnoreCase("summonFel")){
                customMobs.summonFel(player.getLocation());
            }
        if(cmd.getName().equalsIgnoreCase("summonDragon")){
            customMobs.summonDragon(player.getLocation());
        }
            if (cmd.getName().equalsIgnoreCase("loop")) {
                if (args.length >= 2) {
                    try{
                        String command = args[0].toUpperCase();
                        int amount = Integer.parseInt(args[1]);
                        for (int i = 0; i < amount; i++){
                            player.performCommand(command);
                        }
                    }catch(IllegalArgumentException e){
                        player.sendMessage(ChatColor.RED + "Invalid Argument.");
                    }
                } else {
                    player.sendMessage(ChatColor.RED + "Invalid Argument.");
                }
            }if(cmd.getName().equalsIgnoreCase("plugins")){
                player.sendMessage("§aUr mom, §cdeez nuts, §delephant anticheat ");
            }
            if(cmd.getName().equalsIgnoreCase("ferocity")){
                player.sendMessage("FEROCITY GO BRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR");
                new BukkitRunnable(){
                    public void run(){
                        player.playSound(player.getLocation(),Sound.BLOCK_FIRE_AMBIENT, 1, 1);
                    }
                }.runTaskLater(plugin,4L);
                new BukkitRunnable(){
                    public void run(){
                        player.playSound(player.getLocation(),Sound.ENTITY_ZOMBIE_STEP, 1,1);
                        player.playSound(player.getLocation(),Sound.BLOCK_FIRE_EXTINGUISH,0.1f,1);
                        player.playSound(player.getLocation(),Sound.ENTITY_ZOMBIE_BREAK_WOODEN_DOOR,1,1);
                    }
                }.runTaskLater(plugin,2L);
            }
            return true;


        }
//        sender.sendMessage(ChatColor.RED +  "You dont have the required permission to run the command. Contact the server Administrators if you think this is a mistake.");
//        return true;
//    }
}