package me.skyblockitems.skyblockitems;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.attribute.Attributable;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityTeleportEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class customMobs implements Listener {

    static SkyblockItems plugin;

    public customMobs(SkyblockItems plugin){
        customMobs.plugin = plugin;
    }


//  zombie
    public static double zombieMaxHp = 100;
    public static double zombieHp = 100;
    public static void summonZombie(Location location) {
        zombieHp = 100;
        Zombie zombie = location.getWorld().spawn(location, Zombie.class);
        Attributable zombieAt = zombie;
        AttributeInstance attribute = zombieAt.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        attribute.setBaseValue(zombieMaxHp);
        zombie.setHealth(zombieHp);
        zombie.setNoDamageTicks(0);
        ArmorStand as = (ArmorStand) zombie.getWorld().spawnEntity(zombie.getLocation().add(0,2,0),EntityType.ARMOR_STAND);
        as.setArms(false);
        as.setGravity(false);
        as.setVisible(false);
        as.setSmall(true);
        as.setMarker(true);
        as.setInvulnerable(true);
        as.setCollidable(false);

        new BukkitRunnable(){
            public void run(){
                zombieHp = zombie.getHealth();
                if(zombieHp == 0){
                    zombie.remove();
                    as.remove();
                    zombieHp = zombieMaxHp;
                }

                as.teleport(zombie.getLocation().add(0,2,0));
                as.setCustomName(ChatColor.GRAY + "Lv1" + ChatColor.RED + "Zombie " + ChatColor.GREEN + Math.floor(zombieHp) + ChatColor.GRAY + "/" + ChatColor.GREEN + zombieMaxHp );
                as.setCustomNameVisible(true);

            }
        }.runTaskTimer(plugin, 0L, 1L);
        new BukkitRunnable() {
            public void run() {
                if (!zombie.isDead()) {
                    if (zombie.getTarget() != null) {
                        for (Entity entity : zombie.getNearbyEntities(10, 10, 10)) {
                            if (entity instanceof Player) {
                                Player p = (Player) entity;
                                zombie.setTarget(p);
                            }
                        }
                    }
//                 else{
//                        LivingEntity target = zombie.getTarget();
//                        if(target.getLocation().distanceSquared(zombie.getLocation()) > 25){
//
//                        }
//                    }


                } else {
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }
//    @EventHandler
//    public void zombieDamageEvent(EntityDamageByEntityEvent e){
//        if(e.getDamager().getCustomName() == null)
//            return;
//        if(!(e.getDamager() instanceof Zombie && e.getDamager().getCustomName().contains(ChatColor.GRAY + "Lv1" + ChatColor.RED + "Zombie ")))
//            return;
//        e.setDamage( 38 );
//    }

//    necron
    public static double necronMaxHp = 10000000;
    public static double necronMaxHp_internal = necronMaxHp;
    public static double necronHp = 10000000;
    public static void summonNecron(Location location){
        necronHp = 10000000;
        Wither necron = location.getWorld().spawn(location, Wither.class);
        Attributable necronAt = necron;
        AttributeInstance attribute = necronAt.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        attribute.setBaseValue(necronMaxHp_internal);
        necron.setHealth(necronHp);

        new BukkitRunnable(){
            public void run(){
                necronHp = necron.getHealth();
                if(necronHp == 0){
                    necron.remove();
                }if(necronHp < necronMaxHp / 50){
                    necron.setHealth(necronMaxHp_internal);

                }
                necron.setCustomName(ChatColor.GOLD + "﴾" + ChatColor.RED + "§lNECRON" + ChatColor.GOLD + "﴿");
                necron.setCustomNameVisible(true);
            }
        }.runTaskTimer(plugin, 0L, 1L);

        new BukkitRunnable(){
            public void run(){
                if(!necron.isDead()){
                    if(necron.getTarget() != null){
                        for(Entity entity : necron.getNearbyEntities(10,10,10)){
                            if(entity instanceof Player){
                                Player p = (Player) entity;
                                necron.setTarget(p);
                            }
                        }
                    }
                }else{
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);

    }
    // fel
    public static double felMaxHp = 10000;
    public static double felHp = 10000;
    public static void summonFel(Location location){
        felHp = 10000;
        Enderman fel = location.getWorld().spawn(location, Enderman.class);
        Attributable felAt = fel;
        AttributeInstance attribute = felAt.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        attribute.setBaseValue(felMaxHp);
        fel.setHealth(felHp);

        ArmorStand as = (ArmorStand) fel.getWorld().spawnEntity(fel.getLocation().add(0,3,0),EntityType.ARMOR_STAND);
        as.setArms(false);
        as.setGravity(false);
        as.setVisible(false);
        as.setSmall(true);
        as.setMarker(true);
        as.setInvulnerable(true);
        as.setCollidable(false);

        new BukkitRunnable(){
            public void run(){
                felHp = fel.getHealth();
                if(felHp == 0){
                    fel.remove();
                    as.remove();
                    felHp = felMaxHp;
                }
                fel.setCustomName(ChatColor.WHITE + "Dinnerbone");
                fel.setCustomNameVisible(false);

                as.teleport(fel.getLocation());
                as.setCustomName(ChatColor.WHITE + "Fel " + felHp );
                as.setCustomNameVisible(true);

            }
        }.runTaskTimer(plugin, 0L, 1L);

//        new BukkitRunnable(){
//            public void run(){
//                if(!fel.isDead()){
//                    if(fel.getTarget() != null){
//                        for(Entity entity : fel.getNearbyEntities(10, 10, 10)){
//                            if(entity instanceof Player){
//                                Player p = (Player) entity;
//                                fel.setTarget(p);
//                            }
//                        }
//                    }
//                }else{
//                    cancel();
//                }
//
//            }
//        }.runTaskTimer(plugin, 0L, 20L);
    }
    @EventHandler
    public void emanTP(EntityTeleportEvent e){
        if(e.getEntity().getType().equals(EntityType.ENDERMAN)){
            e.setCancelled(true);

        }
    }

    private static double dragonMaxHp = 1000000000.0;
    private static double dragonHp = 1000000000.0;
    public static void summonDragon(Location location) {
        dragonHp = 1000000000;
        EnderDragon dragon = location.getWorld().spawn(location, EnderDragon.class);
        Attributable dragonAt = dragon;

        AttributeInstance attribute = dragonAt.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        attribute.setBaseValue(dragonMaxHp);
        dragon.setHealth(dragonHp);

        ArmorStand as = (ArmorStand) dragon.getWorld().spawnEntity(dragon.getLocation().add(0,3,0),EntityType.ARMOR_STAND);
        as.setArms(false);
        as.setGravity(false);
        as.setVisible(false);
        as.setSmall(true);
        as.setMarker(true);
        as.setInvulnerable(true);
        as.setCollidable(false);
        dragon.setCustomName(ChatColor.RED + "﴾ " + ChatColor.GOLD + "" + ChatColor.BOLD + "Alban " + ChatColor.RED + "﴿");
        dragon.setCustomNameVisible(true);
        new BukkitRunnable(){
            public void run(){
                dragonHp = dragon.getHealth();
                if(dragonHp == 0){
                    dragon.remove();
                    as.remove();
                    dragonHp = dragonMaxHp;
                }
                as.teleport(dragon.getLocation());
                as.setCustomName(ChatColor.RED + "﴾ " + ChatColor.GOLD + "" + ChatColor.BOLD + "Alban " + ChatColor.RED + "﴿ " + dragonHp + " / " + dragonMaxHp );
                as.setCustomNameVisible(true);
            }
        }.runTaskTimer(plugin, 0L, 1L);


    }




    }

