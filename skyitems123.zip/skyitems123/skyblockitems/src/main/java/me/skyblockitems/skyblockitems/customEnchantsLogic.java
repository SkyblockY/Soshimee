package me.skyblockitems.skyblockitems;

import org.bukkit.GameMode;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Collection;




public class customEnchantsLogic implements Listener {
    @EventHandler
    public void onPlayerJoin(BlockBreakEvent e){
        if(!e.getPlayer().getGameMode().equals(GameMode.CREATIVE)) {
            e.setCancelled(true);
        }
        if(e.getPlayer().getInventory().getItemInMainHand() == null)
            return;
        if(!e.getPlayer().getInventory().getItemInMainHand().hasItemMeta())
            return;
        if(!e.getPlayer().getInventory().getItemInMainHand().getItemMeta().hasEnchant(CustomEnchants.TELEKINESIS))
            return;

        Player p = e.getPlayer();
        Block b = e.getBlock();
        Collection<ItemStack> drops = b.getDrops(p.getInventory().getItemInMainHand());

        if(drops.isEmpty())
            return;
        p.getInventory().addItem(drops.iterator().next());

    }
}
