package me.skyblockitems.skyblockitems;

import de.tr7zw.nbtapi.NBTItem;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.Bukkit;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import static me.skyblockitems.skyblockitems.ArmorFunctions.*;
import static me.skyblockitems.skyblockitems.ItemFunctions.HyperionNBT;
import static me.skyblockitems.skyblockitems.ItemFunctions.TerminatorNBT;
import static me.skyblockitems.skyblockitems.ItemManager.NecronsChestplate;
import static me.skyblockitems.skyblockitems.ItemManager.NecronsLeggings;

public class GuiClass implements Listener {

    public static Inventory inv;

    public GuiClass() {
        inv = Bukkit.createInventory(null, 45, "Items");
        initializeItems();
    }
    public void initializeItems() {
        inv.addItem(ItemManager.hyperionItem);
        inv.addItem(ItemManager.terminator);
//        inv.addItem(ItemManager.spacehelm);
        inv.addItem(ItemManager.aotv);
//        inv.addItem(ItemManager.sceptre);
        inv.addItem(ItemManager.Bonemerang);
        inv.addItem(ItemManager.aots);
        inv.addItem(ItemManager.NecronsChestplate);
        inv.addItem(ItemManager.Gyrowand);

    }
    @EventHandler
    public void onInventoryClick(InventoryDragEvent e1) {

        if (e1.getInventory().equals(inv)) {
            e1.setCancelled(true);
        }
    }
    @EventHandler
    public void onInvClick(InventoryClickEvent e){
        Player p = (Player) e.getWhoClicked();

        if(e.getInventory().equals(inv)){
            if(e.getCurrentItem() == null)
                return;
            if(e.getCurrentItem() != null && e.getCurrentItem().getItemMeta() != null &&  e.getCurrentItem().getItemMeta().getDisplayName().contains("Hyperion")){
                e.setCancelled(true);
                p.getInventory().addItem(HyperionNBT.getItem());
            }
            if(e.getCurrentItem() != null && e.getCurrentItem().getItemMeta() != null  &&  e.getCurrentItem().getItemMeta().getDisplayName().contains("Terminator")){
                e.setCancelled(true);
                p.getInventory().addItem(TerminatorNBT.getItem());
            }
            if(e.getCurrentItem() != null &&e.getCurrentItem().equals(ItemManager.aotv)){
                e.setCancelled(true);
                p.getInventory().addItem(ItemManager.aotv);
            }
            if(e.getCurrentItem() != null &&e.getCurrentItem().equals(ItemManager.Bonemerang)){
                    e.setCancelled(true);
                    ItemManager.customdata++;
                    ItemManager.Bonemerang.getItemMeta().setCustomModelData(ItemManager.customdata);
                    ItemMeta meta = ItemManager.Bonemerang.getItemMeta();
                    meta.setCustomModelData(ItemManager.customdata);
                    ItemManager.Bonemerang.setItemMeta(meta);
                    p.sendMessage(String.valueOf(ItemManager.customdata));
                    p.getInventory().addItem(ItemManager.Bonemerang);
            }if(e.getCurrentItem() != null &&e.getCurrentItem().equals(ItemManager.aots)){
                e.setCancelled(true);
                p.getInventory().addItem(ItemManager.aots);
            }if(e.getCurrentItem() != null &&e.getCurrentItem().equals(ItemManager.NecronsChestplate)){
                e.setCancelled(true);

                p.getInventory().addItem(necronChestplateNBT.getItem());
                p.getInventory().addItem(necronLeggingNBT.getItem());
                p.getInventory().addItem(necronBootNBT.getItem());
            }if(e.getCurrentItem() != null &&e.getCurrentItem().equals(ItemManager.Gyrowand)){
                e.setCancelled(true);
                p.getInventory().addItem(ItemManager.Gyrowand);
            }
        }

    }


}
